# Area Selection Capture

<cite>
**Referenced Files in This Document**
- [popup.html](file://popup.html)
- [popup.js](file://popup.js)
- [content.css](file://content.css)
- [preview.html](file://preview.html)
- [preview.js](file://preview.js)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document describes the interactive area selection capture mode for a browser extension. It covers the overlay system creation, mouse event handling, real-time selection box rendering, crosshair cursor behavior, drag-to-select functionality, area validation logic, minimum size requirements, and the cropping process using canvas operations. It also documents the user interaction workflow from overlay creation through selection completion, error handling for invalid selections, and integration with the preview system.

## Project Structure
The extension consists of:
- A popup interface for user controls
- Content styling for overlay visuals
- A preview page for displaying captured selections
- Background scripts for communication between UI and content scripts

```mermaid
graph TB
subgraph "Extension UI"
Popup["Popup UI<br/>popup.html + popup.js"]
Preview["Preview Page<br/>preview.html + preview.js"]
end
subgraph "Content Layer"
Styles["Overlay Styles<br/>content.css"]
end
Popup --> Styles
Preview --> Styles
```

**Section sources**
- [popup.html](file://popup.html)
- [popup.js](file://popup.js)
- [content.css](file://content.css)
- [preview.html](file://preview.html)
- [preview.js](file://preview.js)

## Core Components
- Overlay system: Creates an interactive transparent overlay with a draggable selection region and crosshair cursor.
- Mouse event handlers: Captures mousedown, mousemove, and mouseup events to manage selection state and drawing.
- Real-time selection box rendering: Updates the selection rectangle during drag operations.
- Validation logic: Enforces minimum size constraints and handles invalid selections.
- Canvas cropping: Extracts the selected region from the page screenshot and renders it to the preview.
- Preview integration: Displays the cropped selection in the preview page.

**Section sources**
- [content.css](file://content.css)
- [popup.js](file://popup.js)
- [preview.js](file://preview.js)

## Architecture Overview
The area selection capture mode operates through a coordinated flow between the popup UI, overlay styles, and preview page. The popup triggers overlay creation and selection initiation. The overlay captures mouse events to draw a selection rectangle. On completion, the selection is validated and cropped to a canvas, then sent to the preview page for display.

```mermaid
sequenceDiagram
participant User as "User"
participant Popup as "Popup UI"
participant Overlay as "Overlay System"
participant Preview as "Preview Page"
User->>Popup : "Open selection mode"
Popup->>Overlay : "Create overlay and crosshair"
Overlay->>Overlay : "Capture mousedown/mousemove/mouseup"
Overlay->>Overlay : "Render selection box in real-time"
Overlay->>Overlay : "Validate selection area"
Overlay->>Preview : "Send cropped canvas to preview"
Preview->>User : "Display captured selection"
```

**Diagram sources**
- [popup.js](file://popup.js)
- [content.css](file://content.css)
- [preview.js](file://preview.js)

## Detailed Component Analysis

### Overlay System Creation
The overlay system creates a transparent layer that covers the page content and enables interactive selection. It applies crosshair cursor styling and establishes event listeners for mouse interactions.

Key responsibilities:
- Create overlay container and append to document body
- Apply crosshair cursor styling via CSS
- Initialize selection state (start position, selection rectangle, dragging flag)
- Register mouse event handlers for mousedown, mousemove, and mouseup

Validation and constraints:
- Minimum selection width and height thresholds prevent trivial selections
- Selection coordinates are clamped to viewport boundaries

Real-time rendering:
- On mousemove, update selection rectangle dimensions and redraw
- On mouseup, finalize selection and trigger validation

Canvas cropping:
- Render the page content to a canvas
- Extract the selected region using clipping coordinates
- Send the resulting image data to the preview page

**Section sources**
- [content.css](file://content.css)
- [popup.js](file://popup.js)
- [preview.js](file://preview.js)

### Mouse Event Handling
Mouse events drive the selection lifecycle:
- mousedown: Record initial click position, set dragging flag, clear previous selection
- mousemove: While dragging, compute selection rectangle from initial position to current mouse position, update visual feedback
- mouseup: Stop dragging, finalize selection rectangle, validate area, and proceed to cropping

Event handling specifics:
- Coordinates are normalized to page viewport
- Selection rectangle is drawn as a semi-transparent overlay with border highlights
- Crosshair cursor remains visible during selection

Drag-to-select behavior:
- Selection starts at mousedown and continues while mousemove occurs with button pressed
- On mouseup, the selection is finalized and validated

**Section sources**
- [content.css](file://content.css)
- [popup.js](file://popup.js)

### Real-Time Selection Box Rendering
The selection box is rendered dynamically as the user drags the mouse:
- Draw a rectangle outline with adjustable opacity
- Provide visual feedback for hover and active selection states
- Ensure the rectangle remains within page boundaries

Rendering pipeline:
- Compute width and height from start and current positions
- Clamp negative dimensions to positive values
- Update DOM overlay elements or canvas drawing commands

**Section sources**
- [content.css](file://content.css)
- [popup.js](file://popup.js)

### Crosshair Cursor Implementation
The crosshair cursor enhances precision during selection:
- Applies a custom crosshair pointer to the overlay element
- Remains visible during mousedown and mousemove
- Disappears or reverts to default after selection completes

Cursor styling:
- Defined in the overlay stylesheet
- Ensures consistent appearance across page content

**Section sources**
- [content.css](file://content.css)

### Area Validation Logic and Minimum Size Requirements
Selection validation ensures meaningful captures:
- Enforce minimum width and height thresholds
- Reject selections smaller than configured limits
- Provide user feedback for invalid selections

Validation steps:
- Compare computed selection dimensions against thresholds
- If invalid, reset selection state and show error indicator
- If valid, proceed to cropping and preview

**Section sources**
- [popup.js](file://popup.js)

### Cropping Process Using Canvas Operations
Canvas-based cropping extracts the selected region:
- Render page content to an offscreen canvas
- Clip the selection region using computed coordinates
- Convert the cropped region to image data
- Transmit image data to the preview page

Canvas operations:
- Measure page dimensions and viewport offsets
- Translate coordinates to canvas space
- Perform clipping and export to image format

**Section sources**
- [popup.js](file://popup.js)
- [preview.js](file://preview.js)

### Preview System Integration
The preview page displays the cropped selection:
- Receives image data from the overlay system
- Renders the image in a dedicated preview container
- Provides user controls for saving or discarding the selection

Preview workflow:
- Accept incoming image data
- Update preview UI with captured selection
- Offer actions such as save or cancel

**Section sources**
- [preview.js](file://preview.js)
- [preview.html](file://preview.html)

## Dependency Analysis
The area selection capture mode depends on:
- Overlay styles for visual rendering and cursor behavior
- Popup UI for initiating selection and managing state
- Preview page for displaying results

```mermaid
graph TB
Popup["Popup UI<br/>popup.js"] --> OverlayStyles["Overlay Styles<br/>content.css"]
OverlayStyles --> Preview["Preview Page<br/>preview.js"]
Popup --> Preview
```

**Diagram sources**
- [popup.js](file://popup.js)
- [content.css](file://content.css)
- [preview.js](file://preview.js)

**Section sources**
- [popup.js](file://popup.js)
- [content.css](file://content.css)
- [preview.js](file://preview.js)

## Performance Considerations
- Minimize DOM updates during mousemove by batching or throttling
- Use offscreen canvases for cropping to reduce layout thrashing
- Limit overlay repaints to essential changes
- Avoid unnecessary coordinate conversions between page and canvas spaces

## Troubleshooting Guide
Common issues and resolutions:
- Selection not appearing: Verify overlay creation and CSS application
- Dragging does nothing: Confirm mouse event registration and dragging flag state
- Invalid selection errors: Adjust minimum size thresholds or user guidance
- Preview not updating: Check image data transmission and preview rendering logic

Diagnostic steps:
- Inspect overlay element visibility and z-index
- Log mouse event coordinates and selection state
- Validate canvas dimensions and clipping bounds
- Confirm preview page receives and renders image data

**Section sources**
- [popup.js](file://popup.js)
- [content.css](file://content.css)
- [preview.js](file://preview.js)

## Conclusion
The area selection capture mode integrates an overlay system, precise mouse event handling, real-time selection rendering, robust validation, and canvas-based cropping with a preview page. By following the documented workflow and addressing the troubleshooting points, developers can implement reliable and user-friendly area selection functionality.