# Selection Capture

<cite>
**Referenced Files in This Document**
- [content.js](file://content.js)
- [background.js](file://background.js)
- [manifest.json](file://manifest.json)
- [popup.js](file://popup.js)
- [content.css](file://content.css)
- [preview.js](file://preview.js)
- [popup.html](file://popup.html)
- [preview.html](file://preview.html)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the selection-based capture mode for Google Sheets that uses A1 notation to define the region to capture. It covers:
- Parsing A1 notation into logical row/column indices
- Detecting the grid container and canvas boundaries
- Computing the selection bounding rectangle
- Choosing between simple capture (for small selections) and scroll-stitch capture (for large selections)
- Interacting with the Name Box element to extract the selection
- Integrating with the scroll capture system for extended selections
- Column-based cropping and device pixel ratio compensation
- Automatic decision-making between simple and scroll-based capture
- Edge cases, error handling, and the relationship with Google Sheets’ selection highlighting system

## Project Structure
The extension consists of a Manifest V3 service worker, a content script, a popup UI, and a preview page. The selection capture logic lives in the content script and coordinates with the background script for tab capture and preview/download.

```mermaid
graph TB
subgraph "Extension"
A["manifest.json"]
B["background.js"]
C["content.js"]
D["popup.js"]
E["content.css"]
F["preview.js"]
G["popup.html"]
H["preview.html"]
end
subgraph "Google Sheets Tab"
I["UI"]
J["Name Box"]
K["Grid Canvas"]
L["Selection Highlights"]
end
A --> B
A --> C
D --> B
D --> C
C --> B
C --> I
J --> C
K --> C
L --> C
B --> I
```

**Diagram sources**
- [manifest.json:1-34](file://manifest.json#L1-L34)
- [background.js:1-47](file://background.js#L1-L47)
- [content.js:1-795](file://content.js#L1-L795)
- [popup.js:1-47](file://popup.js#L1-L47)
- [content.css:1-35](file://content.css#L1-L35)
- [preview.js:1-180](file://preview.js#L1-L180)
- [popup.html:1-147](file://popup.html#L1-L147)
- [preview.html](file://preview.html)

**Section sources**
- [manifest.json:1-34](file://manifest.json#L1-L34)
- [background.js:1-47](file://background.js#L1-L47)
- [content.js:1-795](file://content.js#L1-L795)
- [popup.js:1-47](file://popup.js#L1-L47)
- [content.css:1-35](file://content.css#L1-L35)
- [preview.js:1-180](file://preview.js#L1-L180)
- [popup.html:1-147](file://popup.html#L1-L147)
- [preview.html](file://preview.html)

## Core Components
- Selection capture entrypoint: startSelectionCapture()
- A1 notation parser: parseA1Notation() and colToNum()
- Grid discovery: findGridContainer() and findGridCanvasRect()
- Selection bounding rectangle: getSelectionBoundingRect()
- Scroll-stitch capture integration: shared scroll logic with startTallCapture()
- Device pixel ratio compensation: cropToImageData()
- Decision logic: small vs large selection branching
- Name Box extraction: findNameBox()

**Section sources**
- [content.js:293-469](file://content.js#L293-L469)
- [content.js:729-758](file://content.js#L729-L758)
- [content.js:752-758](file://content.js#L752-L758)
- [content.js:473-508](file://content.js#L473-L508)
- [content.js:760-777](file://content.js#L760-L777)
- [content.js:512-529](file://content.js#L512-L529)
- [content.js:692-727](file://content.js#L692-L727)

## Architecture Overview
The selection capture mode orchestrates the following flow:
- Extract the selection text from the Name Box
- Parse A1 notation to logical indices
- Decide between simple capture and scroll-stitch capture based on row count
- For simple capture: capture visible tab, crop to selection bounding rectangle
- For scroll-stitch capture: capture frames, scroll, and stitch vertically until the selection is fully captured
- Send the final image to preview

```mermaid
sequenceDiagram
participant User as "User"
participant Popup as "popup.js"
participant Content as "content.js"
participant BG as "background.js"
participant GS as "Google Sheets"
User->>Popup : Click "Capture Selection"
Popup->>Content : sendMessage({action : "selection"})
Content->>GS : findNameBox()
Content->>Content : parseA1Notation()
Content->>Content : findGridCanvasRect()
alt Small selection (rows <= 3)
Content->>BG : capture-visible
BG-->>Content : dataUrl
Content->>Content : cropToImageData()
Content->>Popup : preview
else Large selection
loop Frames
Content->>BG : capture-visible
BG-->>Content : dataUrl
Content->>Content : cropToImageData()
Content->>Content : scroll (Wheel/scrollTop)
Content->>Content : hasScrolledPastSelection()
end
Content->>Popup : preview
end
```

**Diagram sources**
- [popup.js:10-38](file://popup.js#L10-L38)
- [content.js:293-469](file://content.js#L293-L469)
- [background.js:2-24](file://background.js#L2-L24)

## Detailed Component Analysis

### A1 Notation Parsing
The parser extracts a cell or range from the Name Box text and converts column letters to numeric indices.

- Supports single cells (e.g., "A1") and ranges (e.g., "A1:B2")
- Uses a helper to convert column letters to base-26 numbers
- Returns structured range with start/end row/column indices

```mermaid
flowchart TD
Start(["parseA1Notation(text)"]) --> MatchRange["Match range pattern 'COL1ROW1:COL2ROW2'"]
MatchRange --> |Matched| BuildRange["Build range object<br/>startCol, startRow, endCol, endRow"]
MatchRange --> |No match| MatchCell["Match cell pattern 'COLROW'"]
MatchCell --> |Matched| BuildCell["Build single-cell range"]
MatchCell --> |No match| ReturnNull["Return null"]
BuildRange --> End(["Range object"])
BuildCell --> End
ReturnNull --> End
```

**Diagram sources**
- [content.js:729-750](file://content.js#L729-L750)
- [content.js:752-758](file://content.js#L752-L758)

**Section sources**
- [content.js:729-750](file://content.js#L729-L750)
- [content.js:752-758](file://content.js#L752-L758)

### Grid Container and Canvas Detection
The system identifies the spreadsheet grid container and the primary grid canvas to define the capture area.

- findGridContainer(): scans known selectors and heuristically selects the largest scrollable element
- findGridCanvasRect(): selects the largest visible canvas within the viewport as the grid rectangle

These utilities ensure cropping and stitching operate on the correct grid area.

**Section sources**
- [content.js:473-494](file://content.js#L473-L494)
- [content.js:496-508](file://content.js#L496-L508)

### Selection Bounding Rectangle Calculation
The selection bounding rectangle attempts to compute the visual bounds of the current selection highlights.

- getSelectionBoundingRect(): aggregates the bounding boxes of selection/highlight elements
- Returns null if no highlights are found or if they are too small

This rectangle is used as the crop target for simple captures when available.

**Section sources**
- [content.js:760-777](file://content.js#L760-L777)

### Dual Approach: Small vs Large Selections
The selection capture mode automatically chooses between two strategies:

- Small selection (≤3 rows):
  - Captures the visible tab once
  - Optionally crops to the selection bounding rectangle
  - Sends the result to preview

- Large selection (>3 rows):
  - Resets scroll to top
  - Iteratively captures frames, scrolls, and stitches vertically
  - Stops when duplicates are detected or when the selection is scrolled past
  - Uses the same scroll logic as the tall capture mode

```mermaid
flowchart TD
StartSel(["startSelectionCapture"]) --> GetNameBox["findNameBox()"]
GetNameBox --> Parse["parseA1Notation()"]
Parse --> Rows["Compute totalRows = endRow - startRow + 1"]
Rows --> Small{"totalRows <= 3?"}
Small --> |Yes| Simple["Capture visible tab<br/>cropToImageData()<br/>preview"]
Small --> |No| ScrollLoop["Scroll-stitch loop:<br/>capture -> crop -> scroll -> detect duplicates/past selection"]
ScrollLoop --> DoneSel(["Preview final image"])
Simple --> DoneSel
```

**Diagram sources**
- [content.js:293-469](file://content.js#L293-L469)
- [content.js:512-529](file://content.js#L512-L529)

**Section sources**
- [content.js:293-469](file://content.js#L293-L469)

### Name Box Element Interaction
The Name Box is the source of truth for the selection. The system tries multiple strategies to locate it and extract the selection text.

- Known selectors for the Name Box
- Pattern scanning for cell-like inputs
- Positional heuristic near the top-left corner

Only non-empty values that look like cell references are considered.

**Section sources**
- [content.js:692-727](file://content.js#L692-L727)

### Integration with Scroll Capture System
Large selections reuse the scroll-stitching logic from tall capture:
- Scroll attempts via wheel events on the grid canvas, direct scrollTop, and fallback wheel on the container
- Duplicate frame detection to stop early
- Stopping condition checks whether selection highlights have scrolled above the viewport

This ensures consistent behavior across tall and selection capture modes.

**Section sources**
- [content.js:337-469](file://content.js#L337-L469)
- [content.js:394-441](file://content.js#L394-L441)
- [content.js:779-794](file://content.js#L779-L794)

### Column-Based Cropping and Device Pixel Ratio Compensation
Cropping uses device pixel ratio to ensure crisp images on high-DPI displays.

- cropToImageData(): scales the rectangle by DPR and draws the region into a new canvas
- The resulting image data is used for stitching or final output

This compensates for pixel density differences across devices.

**Section sources**
- [content.js:512-529](file://content.js#L512-L529)

### Automatic Decision-Making Between Simple and Scroll-Based Capture
The decision is based solely on the number of rows in the parsed A1 range:
- If rows ≤ 3, use simple capture
- Otherwise, use scroll-stitch capture

This heuristic balances simplicity and completeness for typical selection sizes.

**Section sources**
- [content.js:311-335](file://content.js#L311-L335)

### Relationship with Google Sheets Selection Highlighting System
Selection highlighting elements are used to:
- Compute the selection bounding rectangle for simple capture
- Determine when the selection has scrolled past the viewport for scroll capture

The presence and visibility of these elements influence capture quality and stopping conditions.

**Section sources**
- [content.js:760-777](file://content.js#L760-L777)
- [content.js:779-794](file://content.js#L779-L794)

## Dependency Analysis
The selection capture mode depends on:
- Content script for DOM discovery, parsing, capture orchestration, and image processing
- Background script for tab capture and preview/download
- Popup for initiating capture and injecting content script/CSS

```mermaid
graph LR
Popup["popup.js"] --> Content["content.js"]
Content --> BG["background.js"]
Content --> CSS["content.css"]
Content --> Preview["preview.js"]
Manifest["manifest.json"] --> BG
Manifest --> Content
```

**Diagram sources**
- [popup.js:10-38](file://popup.js#L10-L38)
- [content.js:1-795](file://content.js#L1-795)
- [background.js:1-47](file://background.js#L1-L47)
- [manifest.json:1-34](file://manifest.json#L1-L34)

**Section sources**
- [popup.js:10-38](file://popup.js#L10-L38)
- [content.js:1-795](file://content.js#L1-L795)
- [background.js:1-47](file://background.js#L1-L47)
- [manifest.json:1-34](file://manifest.json#L1-L34)

## Performance Considerations
- Frame capture cadence: small delays between captures to allow rendering stability
- Duplicate frame detection: stops early when frames repeat, reducing unnecessary captures
- Scroll step sizing: uses a fraction of the grid height to balance speed and accuracy
- Overlap detection refinement: reduces stitching errors by refining overlap search
- DPR compensation: ensures correct pixel counts for cropping and drawing

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and mitigations:
- No selection detected:
  - Ensure a cell or range is selected in Google Sheets so the Name Box shows a cell reference
  - The system ignores empty or non-matching values
- A1 parsing fails:
  - Verify the Name Box contains a valid A1-style reference
  - The parser expects either a single cell or a range with letters and digits
- Selection too large:
  - The mode switches to scroll-stitch automatically; if it stops early, check for duplicate frames or viewport conditions
- Scroll not working:
  - The system tries multiple scroll methods; ensure the grid container is scrollable
- Cropped image looks blurry:
  - Confirm device pixel ratio is detected and cropping uses DPR scaling

**Section sources**
- [content.js:295-299](file://content.js#L295-L299)
- [content.js:302-306](file://content.js#L302-L306)
- [content.js:337-469](file://content.js#L337-L469)
- [content.js:512-529](file://content.js#L512-L529)

## Conclusion
The selection capture mode integrates A1 notation parsing, grid detection, and intelligent capture strategy selection to reliably capture both small and large cell selections from Google Sheets. By leveraging the Name Box, selection highlights, and scroll-stitch logic, it produces high-quality images while compensating for device pixel density and handling edge cases gracefully.