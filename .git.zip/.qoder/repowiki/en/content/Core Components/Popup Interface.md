# Popup Interface

<cite>
**Referenced Files in This Document**
- [background.js](file://background.js)
- [content.css](file://content.css)
- [content.js](file://content.js)
- [preview.html](file://preview.html)
- [preview.js](file://preview.js)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document provides comprehensive technical documentation for the popup interface component of a Chrome extension. The popup serves as the primary user interface for capturing screenshots and managing user workflows. It handles Google Sheets detection, presents actionable buttons for different capture modes, displays status indicators, and coordinates communication with content scripts through a robust message passing system.

The popup interface is designed to provide intuitive user interaction while maintaining reliable detection of Google Sheets contexts and efficient coordination of screenshot operations across different capture modes.

## Project Structure
The extension follows a modular architecture with distinct components handling different aspects of the screenshot functionality:

```mermaid
graph TB
subgraph "Extension Components"
Popup[Popup Interface]
Background[Background Script]
Content[Content Scripts]
Preview[Preview Window]
end
subgraph "Communication Layer"
MessageBus[Message Passing System]
StatusIndicators[Status Indicators]
ActionButtons[Action Buttons]
end
subgraph "Context Detection"
GSDetection[Google Sheets Detection]
ModeSelector[Capture Mode Selection]
Validation[Context Validation]
end
Popup --> MessageBus
Popup --> StatusIndicators
Popup --> ActionButtons
Popup --> GSDetection
MessageBus --> Background
MessageBus --> Content
MessageBus --> Preview
GSDetection --> Validation
ActionButtons --> ModeSelector
```

**Diagram sources**
- [background.js](file://background.js)
- [content.js](file://content.js)
- [preview.js](file://preview.js)

The project structure consists of several key files that work together to provide the complete popup functionality:

**Section sources**
- [background.js](file://background.js)
- [content.js](file://content.js)
- [preview.js](file://preview.js)

## Core Components

### Popup Interface Structure
The popup interface provides a centralized hub for user interaction with the screenshot functionality. It encompasses several critical subsystems:

**Google Sheets Detection Logic**: Intelligent context awareness that identifies when the extension is operating within Google Sheets environments, enabling specialized capture modes and user feedback.

**Action Button System**: Multiple capture mode options presented through clearly labeled buttons, each triggering specific screenshot workflows with appropriate validation and user feedback.

**Status Indicator System**: Real-time feedback mechanisms that communicate operation progress, success/failure states, and contextual information to users.

**Message Passing Infrastructure**: Robust communication channels that coordinate between popup, background script, and content scripts for seamless operation.

### User Interaction Model
The popup implements a state-driven interaction model where user actions trigger specific workflows:

1. **Context Detection Phase**: Automatic identification of Google Sheets environments
2. **Mode Selection Phase**: User chooses appropriate capture mode
3. **Validation Phase**: Context validation and capability assessment
4. **Execution Phase**: Coordinated screenshot capture operation
5. **Feedback Phase**: Status reporting and result presentation

**Section sources**
- [background.js](file://background.js)
- [content.js](file://content.js)

## Architecture Overview

The popup interface operates within a multi-layered architecture that ensures reliable communication and coordinated functionality:

```mermaid
sequenceDiagram
participant User as "User"
participant Popup as "Popup Interface"
participant BG as "Background Script"
participant CS as "Content Script"
participant GS as "Google Sheets"
User->>Popup : Open Extension Popup
Popup->>Popup : Detect Google Sheets Context
Popup->>User : Display Available Actions
User->>Popup : Select Capture Mode
Popup->>BG : Validate Context & Request Permission
BG->>CS : Inject Content Script
CS->>GS : Initialize Screenshot Engine
GS-->>CS : Confirm Capability
CS-->>BG : Report Status
BG-->>Popup : Operation Result
Popup->>User : Display Feedback
Note over Popup,User : Workflow Complete
```

**Diagram sources**
- [background.js](file://background.js)
- [content.js](file://content.js)

The architecture ensures that:
- Context detection occurs automatically without user intervention
- Communication flows are bidirectional and asynchronous
- Error conditions are handled gracefully with user feedback
- Operations are coordinated across multiple script contexts

## Detailed Component Analysis

### Google Sheets Detection System

The Google Sheets detection mechanism employs sophisticated context-aware logic to identify when the extension is operating within Google Sheets environments:

```mermaid
flowchart TD
Start([Popup Load Event]) --> CheckURL["Check Current Tab URL"]
CheckURL --> IsGSEnabled{"Is Google Sheets Detected?"}
IsGSEnabled --> |Yes| EnableGSFeatures["Enable Google Sheets Features"]
IsGSEnabled --> |No| StandardMode["Operate in Standard Mode"]
EnableGSFeatures --> ValidateSheet["Validate Sheet Context"]
ValidateSheet --> SheetValid{"Sheet Valid?"}
SheetValid --> |Yes| AdvancedOptions["Display Advanced Options"]
SheetValid --> |No| BasicOptions["Display Basic Options"]
StandardMode --> BasicOptions
AdvancedOptions --> Ready["Ready for Capture"]
BasicOptions --> Ready
```

**Diagram sources**
- [content.js](file://content.js)

The detection system evaluates multiple factors including:
- Domain-specific URL patterns for Google Sheets
- Presence of sheet-specific DOM elements
- Active sheet identification and validation
- Capability assessment for advanced features

**Section sources**
- [content.js](file://content.js)

### Action Button System

The action button system provides intuitive access to different capture modes through a well-organized interface:

```mermaid
classDiagram
class ActionButton {
+string id
+string label
+string icon
+boolean enabled
+execute() void
+validateContext() boolean
+updateState() void
}
class CaptureMode {
+string modeName
+string description
+execute() Promise
+validate() boolean
}
class GoogleSheetsMode {
+boolean isAdvanced
+boolean hasFormulas
+boolean hasFormatting
+captureVisible() void
+captureEntire() void
+captureSelection() void
}
class StandardMode {
+captureVisible() void
+captureEntire() void
+captureElement() void
}
ActionButton --> CaptureMode : "executes"
CaptureMode <|-- GoogleSheetsMode : "extends"
CaptureMode <|-- StandardMode : "extends"
```

**Diagram sources**
- [content.js](file://content.js)

Each action button implements consistent behavior patterns:
- Context-aware enablement/disablement
- Dynamic label/icon updates based on state
- Integrated validation before execution
- Comprehensive error handling and user feedback

**Section sources**
- [content.js](file://content.js)

### Status Indicator System

The status indicator system provides real-time feedback through multiple visual channels:

```mermaid
stateDiagram-v2
[*] --> Idle
Idle --> Detecting : "User Opens Popup"
Detecting --> Ready : "Context Validated"
Detecting --> Error : "Detection Failed"
Ready --> Executing : "Action Selected"
Executing --> Success : "Operation Complete"
Executing --> Error : "Operation Failed"
Success --> Idle : "Reset"
Error --> Idle : "Reset"
Ready --> Idle : "User Closes"
```

**Diagram sources**
- [content.js](file://content.js)

Status indicators include:
- Loading animations during detection and execution
- Success/error notifications with appropriate messaging
- Context-specific status information
- Progress indicators for long-running operations

**Section sources**
- [content.js](file://content.js)

### Message Passing System

The message passing system enables seamless communication between popup, background script, and content scripts:

```mermaid
sequenceDiagram
participant Popup as "Popup"
participant BG as "Background Script"
participant CS as "Content Script"
participant Tab as "Target Tab"
Note over Popup,BG : Context Detection Request
Popup->>BG : {action : "detectContext"}
BG->>Tab : Query Tab Information
Tab-->>BG : Tab Details
BG-->>Popup : {context : "googleSheets", capabilities : [...]}
Note over Popup,CS : Capture Operation Request
Popup->>BG : {action : "captureScreenshot", mode : "visible"}
BG->>CS : Inject Content Script
CS->>Tab : Execute Capture
Tab-->>CS : Capture Result
CS-->>BG : {status : "success", data : "..."}
BG-->>Popup : {result : "success", url : "..."}
Note over Popup : Error Handling
BG-->>Popup : {error : "operationFailed", message : "..."}
Popup->>Popup : Display Error Notification
```

**Diagram sources**
- [background.js](file://background.js)
- [content.js](file://content.js)

The message passing system supports:
- Asynchronous operation coordination
- Error propagation with meaningful messages
- Context validation and capability checking
- Resource cleanup and state management

**Section sources**
- [background.js](file://background.js)
- [content.js](file://content.js)

## Dependency Analysis

The popup interface maintains loose coupling with other extension components while establishing clear communication channels:

```mermaid
graph TB
subgraph "Popup Dependencies"
PopupCore[Popup Core Logic]
Detector[Context Detector]
Validator[Input Validator]
Messenger[Message Router]
end
subgraph "External Dependencies"
BrowserAPI[Chrome Extension APIs]
DOM[DOM Manipulation]
Storage[Local Storage]
end
subgraph "Internal Dependencies"
Background[Background Script]
Content[Content Scripts]
Preview[Preview System]
end
PopupCore --> Detector
PopupCore --> Validator
PopupCore --> Messenger
Detector --> BrowserAPI
Validator --> DOM
Messenger --> Background
Messenger --> Content
Messenger --> Preview
Background --> Storage
Content --> DOM
Preview --> Storage
```

**Diagram sources**
- [background.js](file://background.js)
- [content.js](file://content.js)

Key dependency relationships:
- **Detector** depends on browser APIs for tab and URL information
- **Validator** relies on DOM manipulation for element selection
- **Messenger** requires background script for cross-context communication
- **Storage** provides persistent state management across sessions

**Section sources**
- [background.js](file://background.js)
- [content.js](file://content.js)

## Performance Considerations

The popup interface is designed with performance optimization in mind:

### Memory Management
- Efficient event listener cleanup to prevent memory leaks
- Lazy loading of heavy resources until needed
- Proper disposal of DOM elements and references

### Network Optimization
- Minimal network requests during normal operation
- Caching of frequently accessed data
- Debounced operations for rapid user interactions

### User Experience Optimization
- Immediate visual feedback for all user actions
- Non-blocking operations using async/await patterns
- Graceful degradation when features are unavailable

## Troubleshooting Guide

Common issues and their resolution strategies:

### Context Detection Failures
**Symptoms**: Google Sheets features not appearing despite being in a spreadsheet
**Resolution Steps**:
1. Verify the popup can access tab information
2. Check if the current URL matches Google Sheets patterns
3. Ensure content script injection is successful
4. Review browser permissions for the extension

### Action Button Issues
**Symptoms**: Buttons appear disabled or unresponsive
**Resolution Steps**:
1. Verify context validation passes
2. Check message passing between popup and background script
3. Ensure content script is properly loaded
4. Review console errors for JavaScript exceptions

### Status Indicator Problems
**Symptoms**: Incorrect status display or missing feedback
**Resolution Steps**:
1. Verify status update functions are called appropriately
2. Check CSS styling for status indicators
3. Ensure proper state transitions occur
4. Validate error handling for edge cases

**Section sources**
- [background.js](file://background.js)
- [content.js](file://content.js)

## Conclusion

The popup interface component represents a sophisticated integration of user interaction, context awareness, and cross-script communication. Its modular design ensures maintainability while providing robust functionality for screenshot capture operations.

Key strengths of the implementation include:
- Intelligent Google Sheets detection with graceful fallbacks
- Comprehensive error handling with user-friendly feedback
- Efficient message passing system supporting complex workflows
- Modular architecture enabling easy extension and maintenance

The component successfully balances functionality with usability, providing users with intuitive access to powerful screenshot capabilities while maintaining reliability and performance across different operating contexts.