# Error Handling and Retry Logic

<cite>
**Referenced Files in This Document**
- [background.js](file://background.js)
- [content.js](file://content.js)
- [popup.js](file://popup.js)
- [preview.js](file://preview.js)
- [manifest.json](file://manifest.json)
- [content.css](file://content.css)
- [popup.html](file://popup.html)
- [preview.html](file://preview.html)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the error handling and retry logic implemented across the extension’s components. It focuses on:
- Retry mechanisms for screenshot capture with exponential backoff
- Error propagation patterns between popup, background, and content scripts
- Validation processes for user inputs, DOM element detection, and network-related errors
- Error reporting, user feedback, and fallback procedures
- Debugging techniques, logging strategies, and troubleshooting across browsers

## Project Structure
The extension follows a Manifest V3 architecture with a service worker background script, a content script injected into Google Sheets pages, a popup UI, and a preview page. Permissions and host permissions are declared in the manifest.

```mermaid
graph TB
subgraph "Browser Extension"
Popup["Popup UI<br/>popup.html + popup.js"]
BG["Background Script<br/>background.js"]
CS["Content Script<br/>content.js + content.css"]
Preview["Preview Page<br/>preview.html + preview.js"]
end
subgraph "Web Pages"
Sheets["Google Sheets Tab"]
end
Popup --> BG
BG --> Sheets
BG --> Preview
CS --> Sheets
Preview --> BG
```

**Diagram sources**
- [manifest.json:19-23](file://manifest.json#L19-L23)
- [popup.js:10-44](file://popup.js#L10-L44)
- [background.js:1-47](file://background.js#L1-L47)
- [content.js:4-9](file://content.js#L4-L9)
- [preview.js:24-32](file://preview.js#L24-L32)

**Section sources**
- [manifest.json:1-34](file://manifest.json#L1-L34)
- [popup.html:112-146](file://popup.html#L112-L146)
- [preview.html:128-146](file://preview.html#L128-L146)

## Core Components
- Background script: Implements a retry loop for tab capture with bounded attempts and fixed delays. Propagates errors to the content script and handles preview/download actions.
- Content script: Orchestrates capture modes, validates DOM elements, injects overlays for area selection, and manages scroll capture with duplicate-frame detection and scroll-fallback strategies.
- Popup: Injects content script and CSS into the active tab, sends capture commands, and closes itself after dispatch.
- Preview: Loads captured images, provides copy-to-clipboard and download actions, and exposes zoom/pan controls.

**Section sources**
- [background.js:1-47](file://background.js#L1-L47)
- [content.js:25-43](file://content.js#L25-L43)
- [popup.js:10-44](file://popup.js#L10-L44)
- [preview.js:24-60](file://preview.js#L24-L60)

## Architecture Overview
The extension uses a message-passing architecture:
- Popup triggers capture actions by sending messages to the content script.
- Content script requests tab captures from the background script.
- Background script performs retries and returns results or errors.
- On success, content script opens the preview page with the captured image.

```mermaid
sequenceDiagram
participant User as "User"
participant Popup as "popup.js"
participant BG as "background.js"
participant CS as "content.js"
participant Preview as "preview.js"
User->>Popup : Click capture button
Popup->>CS : sendMessage({action})
CS->>BG : sendMessage({action : "capture-visible"})
BG->>BG : Attempt capture with retry
BG-->>CS : {dataUrl} or {error}
CS->>Preview : sendMessage({action : "preview", dataUrl, filename})
Preview-->>User : Display image and controls
```

**Diagram sources**
- [popup.js:36-37](file://popup.js#L36-L37)
- [content.js:28-33](file://content.js#L28-L33)
- [background.js:7-22](file://background.js#L7-L22)
- [content.js:34-38](file://content.js#L34-L38)
- [preview.js:24-32](file://preview.js#L24-L32)

## Detailed Component Analysis

### Background Script: Retry Logic for Tab Capture
- Implements a retry loop for tab capture with a fixed maximum number of attempts and a fixed delay between attempts.
- Uses a recursive helper to reattempt capture until successful or until the maximum attempts are exhausted.
- Propagates either the captured image data or an error message back to the content script.

```mermaid
flowchart TD
Start(["Start capture-visible"]) --> Attempt["Attempt capture"]
Attempt --> Success{"Success?"}
Success --> |Yes| RespondData["Respond with dataUrl"]
Success --> |No| CheckAttempts{"Attempts < Max?"}
CheckAttempts --> |Yes| Wait["Wait fixed delay"]
Wait --> Attempt
CheckAttempts --> |No| RespondError["Respond with error message"]
RespondData --> End(["Done"])
RespondError --> End
```

**Diagram sources**
- [background.js:3-24](file://background.js#L3-L24)

**Section sources**
- [background.js:1-47](file://background.js#L1-L47)

### Content Script: Error Propagation and User Feedback
- Validates runtime messaging responses and propagates errors to the UI via alerts.
- Uses a promise wrapper around runtime messages to convert callback-style responses into promises for easier error handling.
- Provides user feedback on capture failures and cancellation via keyboard shortcuts.

```mermaid
sequenceDiagram
participant CS as "content.js"
participant BG as "background.js"
participant UI as "User"
CS->>BG : sendMessage({action : "capture-visible"})
BG-->>CS : {dataUrl} or {error}
alt Success
CS-->>UI : Open preview with image
else Failure
CS-->>UI : alert("Capture failed : ...")
end
```

**Diagram sources**
- [content.js:28-33](file://content.js#L28-L33)
- [content.js:39-42](file://content.js#L39-L42)

**Section sources**
- [content.js:25-43](file://content.js#L25-L43)

### Area Capture Mode: Overlay and Validation
- Creates an overlay for area selection and computes selection dimensions.
- Validates selection size and aborts if too small.
- Captures the visible tab, crops to the selection rectangle, and previews the result.

```mermaid
flowchart TD
Start(["Start area capture"]) --> CreateOverlay["Create overlay and listeners"]
CreateOverlay --> MouseDown["Mouse down to start selection"]
MouseDown --> MouseMove["Update selection and dimensions"]
MouseMove --> MouseUp["Mouse up to finalize selection"]
MouseUp --> ValidateSel{"Selection large enough?"}
ValidateSel --> |No| Cleanup["Remove overlay and exit"]
ValidateSel --> |Yes| Capture["Request tab capture"]
Capture --> Crop["Crop to selection"]
Crop --> Preview["Send to preview"]
Cleanup --> End(["Done"])
Preview --> End
```

**Diagram sources**
- [content.js:47-136](file://content.js#L47-L136)

**Section sources**
- [content.js:47-136](file://content.js#L47-L136)

### Tall Capture Mode: Scroll-Based Retry and Fallbacks
- Resets scroll position and iteratively captures frames with delays.
- Implements duplicate-frame detection to stop early when content stabilizes.
- Uses multiple scroll strategies with fallbacks:
  - Dispatches wheel events on the largest canvas.
  - Falls back to direct scrollTop manipulation.
  - Last-resort wheel event on the container.
- Stops when no scroll occurs for several attempts or when duplicate frames accumulate.

```mermaid
flowchart TD
Start(["Start tall capture"]) --> ResetScroll["Reset scroll to top"]
ResetScroll --> Loop{"Frame < MaxFrames?"}
Loop --> |No| BuildImage["Build final image and preview"]
Loop --> |Yes| Sleep["Sleep before capture"]
Sleep --> Capture["Request tab capture"]
Capture --> Crop["Crop to grid area"]
Crop --> DuplicateCheck{"Duplicate frames?"}
DuplicateCheck --> |Yes| StopEarly["Stop early"]
DuplicateCheck --> |No| Scroll["Try scroll strategies"]
Scroll --> NoScroll{"Scroll occurred?"}
NoScroll --> |No| ConsecutiveNoScroll["Increment counter"]
NoScroll --> |Yes| ConsecutiveNoScroll["Reset counter"]
ConsecutiveNoScroll --> CheckStop{"Too many no-scroll?"}
CheckStop --> |Yes| BuildImage
CheckStop --> |No| Loop
StopEarly --> BuildImage
BuildImage --> End(["Done"])
```

**Diagram sources**
- [content.js:140-289](file://content.js#L140-L289)

**Section sources**
- [content.js:140-289](file://content.js#L140-L289)

### Selection Capture Mode: Range Parsing and Scroll-Stitch
- Detects a named selection and parses A1 notation to determine the range.
- Uses a simple capture for small ranges or scroll-stitch for larger ranges.
- Applies the same scroll strategies and duplicate-frame detection as tall capture.

```mermaid
flowchart TD
Start(["Start selection capture"]) --> Detect["Find name box and parse A1"]
Detect --> SmallRange{"Small range?"}
SmallRange --> |Yes| SimpleCapture["Simple capture and crop"]
SmallRange --> |No| ResetScroll["Reset scroll to top"]
ResetScroll --> Loop{"Frame < MaxFrames?"}
Loop --> |No| BuildImage["Build final image and preview"]
Loop --> |Yes| Sleep["Sleep before capture"]
Sleep --> Capture["Request tab capture"]
Capture --> Crop["Crop to grid area"]
Crop --> DuplicateCheck{"Duplicate frames?"}
DuplicateCheck --> |Yes| StopEarly["Stop early"]
DuplicateCheck --> |No| Scroll["Try scroll strategies"]
Scroll --> PastSelection{"Scrolled past selection?"}
PastSelection --> |Yes| BuildImage
PastSelection --> |No| Loop
SimpleCapture --> Preview["Send to preview"]
BuildImage --> Preview
StopEarly --> Preview
Preview --> End(["Done"])
```

**Diagram sources**
- [content.js:293-469](file://content.js#L293-L469)

**Section sources**
- [content.js:293-469](file://content.js#L293-L469)

### Popup: Injection and Command Dispatch
- Ensures the content script and CSS are injected into the active tab.
- Sends the capture action to the content script and closes the popup.

```mermaid
sequenceDiagram
participant User as "User"
participant Popup as "popup.js"
participant Tab as "Active Tab"
User->>Popup : Click button
Popup->>Tab : executeScript(content.js)
Popup->>Tab : insertCSS(content.css)
Popup->>Tab : sendMessage({action})
Popup-->>User : Close popup
```

**Diagram sources**
- [popup.js:16-37](file://popup.js#L16-L37)

**Section sources**
- [popup.js:10-44](file://popup.js#L10-L44)

### Preview: Copy-to-Clipboard and Download
- Loads the captured image from local storage and displays dimensions.
- Copies the image to the clipboard via the Clipboard API.
- Triggers downloads via the background script.

```mermaid
sequenceDiagram
participant Preview as "preview.js"
participant BG as "background.js"
Preview->>Preview : Load previewData from storage
Preview->>Preview : Display image and dimensions
Preview->>Preview : Copy to clipboard (fetch + ClipboardItem)
Preview->>BG : sendMessage({action : "download", dataUrl, filename})
BG-->>Preview : {downloadId}
```

**Diagram sources**
- [preview.js:24-32](file://preview.js#L24-L32)
- [preview.js:40-55](file://preview.js#L40-L55)
- [preview.js:58-60](file://preview.js#L58-L60)
- [background.js:35-45](file://background.js#L35-L45)

**Section sources**
- [preview.js:24-60](file://preview.js#L24-L60)
- [background.js:35-45](file://background.js#L35-L45)

## Dependency Analysis
- Permissions and host permissions enable tab capture, scripting, downloads, and storage.
- The content script depends on DOM discovery helpers and image processing utilities.
- The popup depends on the background script for tab capture and preview/download actions.

```mermaid
graph LR
Manifest["manifest.json"] --> BG["background.js"]
Manifest --> CS["content.js"]
Manifest --> Popup["popup.js"]
Manifest --> Preview["preview.js"]
Popup --> BG
CS --> BG
BG --> Preview
```

**Diagram sources**
- [manifest.json:6-27](file://manifest.json#L6-L27)

**Section sources**
- [manifest.json:1-34](file://manifest.json#L1-L34)

## Performance Considerations
- Fixed-delay retries reduce CPU usage compared to tight loops but may increase latency under transient failures.
- Duplicate-frame detection prevents unnecessary captures and reduces stitching overhead.
- Scroll strategies prioritize the largest canvas for wheel events to minimize layout thrashing.
- Image processing uses canvas operations; consider reducing resolution or sampling for very large captures.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide

### Screenshot Capture Failures
- Symptom: Immediate failure with an error message.
- Likely causes: Tab capture permission denied, transient tab state, or browser-specific restrictions.
- Actions:
  - Verify permissions in the manifest.
  - Retry the capture after a short delay.
  - Check for browser-specific limitations (some browsers restrict capture of certain tabs).

**Section sources**
- [background.js:13-19](file://background.js#L13-L19)
- [content.js:39-42](file://content.js#L39-L42)

### Area Selection Too Small
- Symptom: Selection capture aborts without an error.
- Cause: Selection smaller than the minimum threshold.
- Actions: Choose a larger selection area or use the screenshot mode.

**Section sources**
- [content.js:98-99](file://content.js#L98-L99)

### Scroll Capture Stalls or Stops Early
- Symptom: Tall or selection capture stops after a few frames.
- Causes:
  - No scroll occurred for several attempts.
  - Duplicate frames detected beyond the threshold.
  - Selection scrolled past the viewport.
- Actions:
  - Ensure the grid container is scrollable.
  - Try the selection capture mode for precise ranges.
  - Use the Escape key to cancel and restart.

**Section sources**
- [content.js:248-253](file://content.js#L248-L253)
- [content.js:190-201](file://content.js#L190-L201)
- [content.js:376-389](file://content.js#L376-L389)

### Preview Not Loading or Dimensions Missing
- Symptom: Preview loads but shows missing dimensions or fails to copy.
- Causes: Data not stored in local storage or clipboard access blocked.
- Actions:
  - Confirm the preview page receives dataUrl and filename.
  - Check clipboard permissions and try again.
  - Reopen the preview page to reload data.

**Section sources**
- [preview.js:24-37](file://preview.js#L24-L37)
- [preview.js:40-55](file://preview.js#L40-L55)

### Logging and Debugging Techniques
- Enable developer mode in Chrome Extensions and inspect background/service worker logs.
- Use console logs to trace capture attempts, scroll positions, and duplicate-frame checks.
- For DOM detection issues, log selector results and element visibility to confirm discovery strategies.

**Section sources**
- [content.js:145-156](file://content.js#L145-L156)
- [content.js:257-259](file://content.js#L257-L259)
- [content.js:465-467](file://content.js#L465-L467)

### Cross-Browser Compatibility Notes
- Some browsers impose stricter policies on tab capture and clipboard access.
- If injection fails, verify content script permissions and host permissions.
- Test on different Chromium-based browsers to identify environment-specific issues.

**Section sources**
- [manifest.json:6-7](file://manifest.json#L6-L7)
- [popup.js:17-24](file://popup.js#L17-L24)

## Conclusion
The extension implements a robust error handling and retry framework centered on a fixed-delay retry loop for tab capture, complemented by validation and fallback strategies across capture modes. Error propagation is straightforward, with runtime messaging errors converted to user-visible alerts. The preview and download pathways provide immediate user feedback and fallbacks for clipboard access. For production hardening, consider adding exponential backoff, jitter, and more granular error categorization to improve resilience and diagnostics.