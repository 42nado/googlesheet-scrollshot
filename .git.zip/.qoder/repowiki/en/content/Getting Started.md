# Getting Started

<cite>
**Referenced Files in This Document**
- [manifest.json](file://manifest.json)
- [popup.html](file://popup.html)
- [popup.js](file://popup.js)
- [content.js](file://content.js)
- [content.css](file://content.css)
- [background.js](file://background.js)
- [preview.html](file://preview.html)
- [preview.js](file://preview.js)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Installation and Setup](#installation-and-setup)
3. [First-Time User Walkthrough](#first-time-user-walkthrough)
4. [Popup Interface Overview](#popup-interface-overview)
5. [Capture Modes](#capture-modes)
6. [Basic Usage Patterns](#basic-usage-patterns)
7. [Developer Mode and Unpacked Loading](#developer-mode-and-unpacked-loading)
8. [Permissions and Security](#permissions-and-security)
9. [Troubleshooting Common Issues](#troubleshooting-common-issues)
10. [Expected Outcomes by Mode](#expected-outcomes-by-mode)
11. [Conclusion](#conclusion)

## Introduction
The Google Sheets Screenshot Chrome Extension helps you capture screenshots of Google Sheets documents quickly and efficiently. It provides multiple capture modes including standard screenshots, area selection, scroll captures, and selection-based captures. The extension works by injecting a content script into Google Sheets pages and using Chrome's native capture capabilities.

## Installation and Setup
Follow these steps to install and set up the extension:

### Prerequisites
- Google Chrome browser (latest version recommended)
- Access to Google Sheets (any sheet will work)

### Initial Setup Steps
1. **Enable Developer Mode** in Chrome:
   - Open Chrome and navigate to `chrome://extensions/`
   - Toggle "Developer mode" to ON in the top right corner

2. **Load the Extension**:
   - Click "Load unpacked" button
   - Select the extension folder containing all extension files
   - The extension icon should appear in your Chrome toolbar

3. **Grant Permissions**:
   - Chrome will display permission prompts during installation
   - Approve permissions for accessing tabs, downloads, and storage

**Section sources**
- [manifest.json:6-7](file://manifest.json#L6-L7)
- [manifest.json:24-30](file://manifest.json#L24-L30)

## First-Time User Walkthrough
Complete this walkthrough to capture your first screenshot:

### Step 1: Open a Google Sheet
- Navigate to any Google Sheet document
- Ensure the sheet is fully loaded and interactive

### Step 2: Access the Extension
- Click the extension icon in your Chrome toolbar
- The popup interface will appear with capture options

### Step 3: Choose Your Capture Mode
- Select the appropriate capture mode for your needs
- Click the button to initiate capture

### Step 4: Review and Save
- The preview page will open automatically
- Use the preview controls to copy or download your screenshot

**Section sources**
- [popup.html:138-177](file://popup.html#L138-L177)
- [popup.js:14-20](file://popup.js#L14-L20)

## Popup Interface Overview
The extension popup provides a clean interface with four main capture options:

### Interface Elements
- **Header**: Shows "Sheets Screenshot" title and description
- **Four Capture Buttons**: Each with icon, label, and description
- **Status Area**: Displays feedback messages
- **Non-Sheets Notice**: Appears when not on a Google Sheet

### Button Descriptions
- **Screenshot**: Captures the currently visible area
- **Area Screenshot**: Allows dragging to select a specific region
- **Scroll Capture**: Captures the entire scrollable content
- **Capture Selection**: Captures the currently selected cells

**Section sources**
- [popup.html:67-169](file://popup.html#L67-L169)
- [popup.js:14-20](file://popup.js#L14-L20)

## Capture Modes
The extension offers four distinct capture modes, each designed for different use cases:

### 1. Standard Screenshot
- Captures the currently visible portion of the spreadsheet
- Fastest option for small sheets or partial views
- Ideal for quick snapshots of visible data

### 2. Area Screenshot
- Interactive selection tool for precise regions
- Drag to select any rectangular area
- Perfect for capturing specific data sections

### 3. Scroll Capture
- Automatically captures entire scrollable content
- Handles large spreadsheets with many rows/columns
- Uses intelligent stitching to combine multiple frames

### 4. Selection Capture
- Captures the currently selected cells only
- Works with single cells, ranges, or entire columns/rows
- Automatically handles both small and large selections

**Section sources**
- [popup.html:139-169](file://popup.html#L139-L169)
- [content.js:11-21](file://content.js#L11-L21)

## Basic Usage Patterns
Here are practical usage scenarios for each capture mode:

### Quick Visible Area Capture
1. Open your Google Sheet
2. Click the extension icon
3. Select "Screenshot"
4. Review in preview page
5. Download or copy as needed

### Precise Region Capture
1. Open your sheet and position the view
2. Click "Area Screenshot"
3. Drag to select desired region
4. Release to capture
5. Review and save

### Complete Sheet Capture
1. Open your large spreadsheet
2. Click "Scroll Capture"
3. Watch the automatic capture process
4. Stop with Escape key if needed
5. Review the stitched result

### Selected Data Capture
1. Select cells, ranges, or columns in Google Sheets
2. Click "Capture Selection"
3. Extension captures only the selection
4. Review and export

**Section sources**
- [popup.js:22-86](file://popup.js#L22-L86)
- [content.js:196-440](file://content.js#L196-L440)

## Developer Mode and Unpacked Loading
### Enabling Developer Mode
1. Go to `chrome://extensions/`
2. Toggle "Developer mode" switch to ON
3. Developer mode enables advanced extension features

### Loading Unpacked Extension
1. Click "Load unpacked" button
2. Browse to the extension folder
3. Select the folder containing all extension files
4. Verify the extension appears in the extensions list

### Extension Folder Contents
Ensure your folder contains all required files:
- `manifest.json` (extension definition)
- `popup.html` and `popup.js` (interface)
- `content.js` and `content.css` (sheet integration)
- `background.js` (background processing)
- `preview.html` and `preview.js` (preview page)
- `icons/` directory with icon files

**Section sources**
- [manifest.json:1-37](file://manifest.json#L1-L37)

## Permissions and Security
The extension requires specific permissions to function properly:

### Required Permissions
- **activeTab**: Access the currently active tab for capture operations
- **scripting**: Inject content scripts into Google Sheets
- **downloads**: Enable direct image downloads
- **tabs**: Access tab information and capture visible areas
- **storage**: Store temporary preview data

### Host Permissions
- **https://docs.google.com/**: Full access to Google Sheets
- **<all_urls>**: General web access for preview functionality

### Security Considerations
- Permissions are only requested during installation
- No personal data is collected or transmitted
- All processing happens locally in your browser
- Preview data is temporarily stored in Chrome's local storage

**Section sources**
- [manifest.json:6-7](file://manifest.json#L6-L7)
- [manifest.json:31-36](file://manifest.json#L31-L36)

## Troubleshooting Common Issues
### Issue: Extension Not Showing Up
**Symptoms**: Extension icon missing from toolbar
**Solutions**:
- Verify Developer mode is enabled in `chrome://extensions/`
- Check if the extension loaded successfully
- Look for error messages in the extensions page

### Issue: Cannot Capture on Non-Sheet Pages
**Symptoms**: "Open a Google Sheet to use this extension" message
**Solutions**:
- Navigate to a Google Sheet document
- Ensure the URL contains `docs.google.com/spreadsheets`
- Wait for the sheet to fully load

### Issue: Capture Fails or Returns Empty
**Solutions**:
- Refresh the Google Sheet page
- Try again after a short delay
- Check that the sheet is not protected or restricted
- Ensure sufficient memory is available

### Issue: Scroll Capture Stops Prematurely
**Solutions**:
- Press Escape key to cancel and restart
- Ensure the sheet has scrollable content
- Try capturing smaller sections
- Close other tabs to free up resources

### Issue: Area Selection Not Working
**Solutions**:
- Click and drag slowly to avoid accidental releases
- Ensure the selection area is at least 5x5 pixels
- Try selecting a different region
- Refresh the page if the overlay persists

**Section sources**
- [popup.js:14-20](file://popup.js#L14-L20)
- [content.js:98-131](file://content.js#L98-L131)
- [background.js:29-40](file://background.js#L29-L40)

## Expected Outcomes by Mode
### Standard Screenshot
- **What You Get**: PNG image of visible spreadsheet area
- **File Size**: Typically small, proportional to viewport
- **Quality**: High DPI, maintains spreadsheet clarity
- **Best For**: Quick previews, small selections

### Area Screenshot
- **What You Get**: Cropped PNG of selected region
- **File Size**: Depends on selection dimensions
- **Quality**: Exact pixel-for-pixel capture
- **Best For**: Specific data sections, reports

### Scroll Capture
- **What You Get**: Single PNG with complete content
- **File Size**: Larger, contains entire scrollable area
- **Quality**: Stiched together with minimal seams
- **Best For**: Large spreadsheets, complete views

### Selection Capture
- **What You Get**: PNG of selected cells only
- **File Size**: Medium, depends on selection size
- **Quality**: Optimized for selected content
- **Best For**: Sharing specific data, analysis

**Section sources**
- [background.js:42-54](file://background.js#L42-L54)
- [content.js:117-131](file://content.js#L117-L131)
- [content.js:428-433](file://content.js#L428-L433)

## Conclusion
The Google Sheets Screenshot extension provides a powerful yet intuitive way to capture spreadsheet content. By understanding the different capture modes and following the setup instructions, you can efficiently capture everything from quick visible areas to complete scrollable sheets. The extension's design ensures privacy and security while providing professional-grade screenshot capabilities for your Google Sheets workflow.

For best results, start with the Standard Screenshot mode for simple captures, use Area Screenshot for precise selections, and leverage Scroll Capture for large documents. The preview interface makes it easy to review and export your captures with the built-in copy and download functionality.