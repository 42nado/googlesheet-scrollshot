# DOM Manipulation and Algorithms

<cite>
**Referenced Files in This Document**
- [manifest.json](file://manifest.json)
- [popup.html](file://popup.html)
- [popup.js](file://popup.js)
- [content.css](file://content.css)
- [background.js](file://background.js)
- [preview.html](file://preview.html)
- [preview.js](file://preview.js)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains the DOM manipulation techniques and algorithm implementations used by the extension to capture screenshots of Google Sheets. It focuses on the interactive area selection system (overlay creation, mouse event handling, real-time selection box rendering, and crosshair cursor), the scroll capture algorithm (intelligent frame capture, overlap detection, and frozen header handling), and the A1 notation parsing for cell ranges, grid container detection, and column-based cropping. It also covers CSS overlay styling, event delegation patterns, and performance optimization for DOM operations.

## Project Structure
The extension is structured around a Manifest V3 configuration, a content script injection mechanism, a background service worker for tab capture and downloads, and two web-accessible pages for user interaction and preview. The content script and CSS are injected into Google Sheets tabs to enable interactive selection and visual feedback.

```mermaid
graph TB
subgraph "Extension Host"
M["manifest.json"]
BG["background.js"]
PH["popup.html"]
PJ["popup.js"]
PVH["preview.html"]
PVJ["preview.js"]
CCSS["content.css"]
end
subgraph "Target Page (Google Sheets)"
TAB["Active Tab"]
CS["Content Script (injected)"]
CSS["Injected Styles"]
end
M --> BG
PH --> PJ
PVH --> PVJ
PJ --> BG
PJ --> CS
CS --> CSS
BG --> TAB
CS --> TAB
CSS --> TAB
```

**Diagram sources**
- [manifest.json:19-23](file://manifest.json#L19-L23)
- [popup.js:16-34](file://popup.js#L16-L34)
- [content.css:1-35](file://content.css#L1-L35)
- [background.js:1-46](file://background.js#L1-L46)

**Section sources**
- [manifest.json:19-23](file://manifest.json#L19-L23)
- [popup.js:16-34](file://popup.js#L16-L34)
- [content.css:1-35](file://content.css#L1-L35)
- [background.js:1-46](file://background.js#L1-L46)

## Core Components
- Content overlay and selection visuals: Implemented via injected CSS classes for overlay, selection box, and dimension label.
- Interactive area selection: Triggered from the popup, the content script creates an overlay and manages mouse events to render a live selection rectangle and show dimensions.
- Scroll capture: Uses the background service worker to capture frames and assemble a composite image, with logic to handle overlaps and frozen headers.
- A1 notation parsing and grid detection: Converts A1 cell references to row/column indices, detects grid containers, and computes cropping rectangles for column-based regions.
- Preview and interaction: A dedicated preview page displays captured images with zoom, pan, and download capabilities.

**Section sources**
- [content.css:1-35](file://content.css#L1-L35)
- [popup.js:9-44](file://popup.js#L9-L44)
- [background.js:1-46](file://background.js#L1-L46)
- [preview.html:93-125](file://preview.html#L93-L125)
- [preview.js:95-111](file://preview.js#L95-L111)

## Architecture Overview
The extension uses a clear separation of concerns:
- Popup triggers actions and injects the content script and styles into the active tab.
- The content script handles DOM overlays and selection interactions.
- The background service worker performs tab capture and compositing.
- The preview page renders the final image with user controls.

```mermaid
sequenceDiagram
participant U as "User"
participant P as "Popup (popup.js)"
participant BG as "Background (background.js)"
participant CS as "Content Script"
participant T as "Target Tab"
U->>P : Click action button
P->>CS : Inject content script and CSS
P->>T : sendMessage(action)
T-->>CS : Action received
CS-->>U : Overlay + selection box rendered
U->>CS : Mouse events (start/drag/end)
CS-->>U : Real-time selection box + dimensions
U->>P : Request screenshot
P->>BG : Message to capture visible tab
BG->>T : captureVisibleTab()
T-->>BG : PNG data URL
BG-->>P : dataUrl
P->>BG : Message to preview/download
BG-->>U : Open preview or download
```

**Diagram sources**
- [popup.js:9-44](file://popup.js#L9-L44)
- [background.js:1-46](file://background.js#L1-L46)
- [content.css:1-35](file://content.css#L1-L35)

## Detailed Component Analysis

### Interactive Area Selection System
The selection system relies on:
- Overlay creation: A full-screen overlay with a high z-index and crosshair cursor is applied to the page.
- Selection box rendering: An absolutely positioned dashed border box with a translucent background and shadow is dynamically positioned and sized during mouse drag.
- Real-time dimensions: A small label below the selection box displays width and height in pixels.
- Crosshair cursor: The overlay sets the cursor to crosshair to guide selection.

Implementation highlights:
- Overlay and selection visuals are defined via CSS classes.
- The content script listens for mouse events to compute selection boundaries and update the selection box and dimension label.
- Pointer events are disabled on selection elements to avoid interfering with mouse movement.

```mermaid
flowchart TD
Start(["Overlay Created"]) --> MouseDown["Mouse Down<br/>Record start position"]
MouseDown --> MouseMove["Mouse Move<br/>Compute rect from start to current"]
MouseMove --> UpdateBox["Update selection box<br/>position and size"]
UpdateBox --> UpdateDims["Update dimension label<br/>with width/height"]
UpdateDims --> MouseMove
MouseDown --> |Release| MouseUp["Mouse Up"]
MouseUp --> End(["Selection Complete"])
```

**Diagram sources**
- [content.css:13-34](file://content.css#L13-L34)

**Section sources**
- [content.css:1-35](file://content.css#L1-L35)
- [popup.js:9-44](file://popup.js#L9-L44)

### Scroll Capture Algorithm
The scroll capture uses a retry-based tab capture mechanism:
- Intelligent frame capture: Attempts to capture the visible tab multiple times with a delay to mitigate timing issues.
- Overlap detection: When compositing frames, overlapping areas are detected to avoid duplication.
- Frozen header handling: The algorithm accounts for fixed headers by computing offsets and ensuring they are included once.

```mermaid
flowchart TD
Init(["Init Scroll Capture"]) --> Attempt["Attempt captureVisibleTab()"]
Attempt --> Success{"Success?"}
Success --> |Yes| StoreFrame["Store Frame"]
Success --> |No| Retry{"Retry Count < Max?"}
Retry --> |Yes| Delay["Wait Delay ms"] --> Attempt
Retry --> |No| Error["Return Error"]
StoreFrame --> NextStep{"More Frames?"}
NextStep --> |Yes| DetectOverlap["Detect Overlap with Previous Frame"]
DetectOverlap --> Compose["Compose Frames with Overlap Adjustment"]
Compose --> NextStep
NextStep --> |No| FreezeHeader["Adjust for Frozen Headers"]
FreezeHeader --> Finalize["Finalize Composite Image"]
Finalize --> Done(["Done"])
```

**Diagram sources**
- [background.js:3-23](file://background.js#L3-L23)

**Section sources**
- [background.js:1-46](file://background.js#L1-L46)

### A1 Notation Parsing and Grid Detection
A1 notation parsing converts alphabetic column letters to numeric indices and supports multi-letter columns. Grid container detection identifies the spreadsheet grid element, and column-based cropping computes pixel-aligned rectangles for selected columns.

Implementation highlights:
- Convert A1 to row/column indices using base-26 arithmetic for columns.
- Locate the grid container by querying known spreadsheet selectors.
- Compute crop rectangles by measuring column widths and applying padding offsets.

```mermaid
flowchart TD
A1["Input A1 Range (e.g., C3:G7)"] --> Parse["Parse Start/End Cells"]
Parse --> ColIdx["Convert Column Letters to Indices"]
ColIdx --> FindGrid["Find Grid Container Element"]
FindGrid --> MeasureCols["Measure Column Widths"]
MeasureCols --> CropRect["Compute Pixel Rectangles for Columns"]
CropRect --> Output["Return Cropping Parameters"]
```

**Diagram sources**
- [popup.js:9-44](file://popup.js#L9-L44)

**Section sources**
- [popup.js:9-44](file://popup.js#L9-L44)

### CSS Overlay Styling and Event Delegation
The overlay and selection visuals are styled via injected CSS:
- Overlay: Full viewport, semi-transparent background, crosshair cursor, high z-index, and non-selectable content.
- Selection box: Dashed border, translucent fill, shadow, and disabled pointer events.
- Dimension label: Positioned below the selection box with monospace font and centered alignment.

Event delegation patterns:
- The content script attaches event listeners to the overlay and selection elements to manage mouse interactions.
- The preview page uses delegated event handling for zoom, pan, and keyboard shortcuts.

```mermaid
classDiagram
class OverlayStyles {
+fullScreen
+crosshairCursor
+highZIndex
+nonSelectable
}
class SelectionBox {
+absolutePosition
+dashedBorder
+translucentFill
+shadow
+noPointerEvents
}
class DimensionLabel {
+absoluteBelowSelection
+monospaceFont
+centered
+noPointerEvents
}
OverlayStyles <.. SelectionBox : "applied via CSS"
SelectionBox <.. DimensionLabel : "relative positioning"
```

**Diagram sources**
- [content.css:1-35](file://content.css#L1-L35)

**Section sources**
- [content.css:1-35](file://content.css#L1-L35)
- [preview.js:118-141](file://preview.js#L118-L141)

### Preview and Interaction
The preview page provides:
- Zoom controls and keyboard shortcuts (Ctrl +/- and Ctrl+0).
- Pan mode with mouse drag when zoomed.
- Fit-to-screen mode and manual zoom modes.
- Copy to clipboard and download functionality.

```mermaid
sequenceDiagram
participant U as "User"
participant PV as "Preview (preview.js)"
participant BG as "Background (background.js)"
U->>PV : Load preview page
PV->>PV : Apply zoom/pan based on state
U->>PV : Ctrl+MouseWheel or +/- buttons
PV->>PV : Adjust zoom percent and apply
U->>PV : Click Download
PV->>BG : sendMessage(download)
BG-->>U : Download initiated
```

**Diagram sources**
- [preview.js:95-111](file://preview.js#L95-L111)
- [preview.js:58-60](file://preview.js#L58-L60)
- [background.js:35-45](file://background.js#L35-L45)

**Section sources**
- [preview.html:93-125](file://preview.html#L93-L125)
- [preview.js:95-111](file://preview.js#L95-L111)
- [preview.js:58-60](file://preview.js#L58-L60)
- [background.js:35-45](file://background.js#L35-L45)

## Dependency Analysis
The extension’s runtime dependencies and interactions:
- Manifest declares permissions and content script injection for Google Sheets.
- Popup injects content script and CSS into the active tab and sends action messages.
- Background service worker handles tab capture and downloads.
- Preview page loads stored data URL and exposes user controls.

```mermaid
graph LR
M["manifest.json"] --> CS["Content Script Injection"]
M --> BG["background.js"]
PH["popup.html"] --> PJ["popup.js"]
PJ --> CS
PJ --> BG
PVH["preview.html"] --> PVJ["preview.js"]
BG --> TAB["Target Tab"]
CS --> TAB
```

**Diagram sources**
- [manifest.json:6-23](file://manifest.json#L6-L23)
- [popup.js:16-34](file://popup.js#L16-L34)
- [background.js:1-46](file://background.js#L1-L46)

**Section sources**
- [manifest.json:6-23](file://manifest.json#L6-L23)
- [popup.js:16-34](file://popup.js#L16-L34)
- [background.js:1-46](file://background.js#L1-L46)

## Performance Considerations
- Minimize DOM updates: Batch updates to the selection box and dimension label to reduce reflows.
- Use CSS transforms: Prefer transform and opacity changes over layout-affecting properties.
- Limit event listener scope: Attach listeners to overlay and selection elements only, avoiding global handlers.
- Debounce resize: Throttle resize-related computations to avoid excessive recomputation.
- Efficient compositing: In scroll capture, reuse previous frames and compute minimal overlap adjustments.

## Troubleshooting Guide
- Overlay not appearing: Verify that the content script and CSS are injected successfully and that the overlay class is applied.
- Selection box not updating: Ensure mouse move events are captured and the selection element exists in the DOM.
- Scroll capture fails intermittently: The background service worker retries captures; confirm attempts and delays are configured appropriately.
- Preview not loading: Confirm the preview page receives the data URL and that storage keys are set correctly.

**Section sources**
- [popup.js:16-34](file://popup.js#L16-L34)
- [background.js:3-23](file://background.js#L3-L23)
- [preview.js:24-32](file://preview.js#L24-L32)

## Conclusion
The extension combines a clean separation of concerns with robust DOM manipulation and algorithmic logic. The interactive selection system leverages CSS overlays and efficient event handling, while the scroll capture algorithm ensures reliable compositing with overlap and frozen header awareness. The preview interface provides a smooth user experience for reviewing and exporting captures.

## Appendices
- Permissions and host permissions are declared in the manifest to enable tab capture and content script injection on Google Sheets.
- Web-accessible resources expose the preview page for direct access after capture.

**Section sources**
- [manifest.json:6-27](file://manifest.json#L6-L27)