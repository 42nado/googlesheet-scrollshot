# Capture Modes

<cite>
**Referenced Files in This Document**
- [manifest.json](file://manifest.json)
- [content.js](file://content.js)
- [background.js](file://background.js)
- [popup.js](file://popup.js)
- [preview.js](file://preview.js)
- [content.css](file://content.css)
- [popup.html](file://popup.html)
- [preview.html](file://preview.html)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the screenshot capture modes implemented in the extension, focusing on four primary approaches:
- Visible area capture
- Interactive area selection with crosshair and selection box
- Intelligent scroll capture with overlap detection and frozen header handling
- Selection-based capture using A1 notation parsing

It covers user interaction patterns, implementation details, algorithms, practical examples, limitations, and performance considerations. Where applicable, diagrams map to actual source files to clarify how the extension’s components collaborate.

## Project Structure
The extension consists of a browser extension manifest, background script, content scripts, and UI pages for popup and preview. The capture modes are implemented primarily in the content script and coordinated via messaging from the popup to the background script and content script.

```mermaid
graph TB
Manifest["manifest.json"]
PopupJS["popup.js"]
BackgroundJS["background.js"]
ContentJS["content.js"]
PreviewJS["preview.js"]
ContentCSS["content.css"]
PopupHTML["popup.html"]
PreviewHTML["preview.html"]
Manifest --> BackgroundJS
PopupJS --> BackgroundJS
BackgroundJS --> ContentJS
ContentJS --> PreviewJS
PopupHTML --> PopupJS
PreviewHTML --> PreviewJS
ContentCSS --> ContentJS
```

**Diagram sources**
- [manifest.json](file://manifest.json)
- [popup.js](file://popup.js)
- [background.js](file://background.js)
- [content.js](file://content.js)
- [preview.js](file://preview.js)
- [content.css](file://content.css)
- [popup.html](file://popup.html)
- [preview.html](file://preview.html)

**Section sources**
- [manifest.json](file://manifest.json)
- [popup.js](file://popup.js)
- [background.js](file://background.js)
- [content.js](file://content.js)
- [preview.js](file://preview.js)
- [content.css](file://content.css)
- [popup.html](file://popup.html)
- [preview.html](file://preview.html)

## Core Components
- manifest.json: Declares permissions, background script, content scripts, and UI pages.
- popup.js: Manages user interface actions and dispatches capture commands to the active tab.
- background.js: Handles cross-tab messaging, tab lifecycle, and orchestrates capture coordination.
- content.js: Implements the core capture logic, DOM interactions, and rendering of selection overlays.
- preview.js: Receives captured image data and displays it in the preview page.
- content.css: Provides overlay styles for selection visuals (crosshair, selection box).
- popup.html and preview.html: Provide lightweight UI shells for the popup and preview.

Key responsibilities:
- popup.js sends capture mode requests to the active tab.
- background.js ensures the content script is injected and handles messaging.
- content.js performs DOM queries, scroll calculations, overlay rendering, and image composition.
- preview.js receives pixel data and renders previews.

**Section sources**
- [manifest.json](file://manifest.json)
- [popup.js](file://popup.js)
- [background.js](file://background.js)
- [content.js](file://content.js)
- [preview.js](file://preview.js)
- [content.css](file://content.css)
- [popup.html](file://popup.html)
- [preview.html](file://preview.html)

## Architecture Overview
The capture pipeline is event-driven and message-based:
- User triggers a capture mode from the popup.
- The background script injects or activates the content script in the target tab.
- The content script executes the selected capture mode, rendering overlays and capturing images.
- Captured image data is sent to the preview page for display.

```mermaid
sequenceDiagram
participant User as "User"
participant Popup as "popup.js"
participant BG as "background.js"
participant Content as "content.js"
participant Preview as "preview.js"
User->>Popup : "Select capture mode"
Popup->>BG : "Send capture command"
BG->>Content : "Inject/activate content script"
Content->>Content : "Render overlays<br/>Perform capture"
Content-->>Preview : "Image data"
Preview-->>User : "Display preview"
```

**Diagram sources**
- [popup.js](file://popup.js)
- [background.js](file://background.js)
- [content.js](file://content.js)
- [preview.js](file://preview.js)

## Detailed Component Analysis

### Visible Area Capture
Overview:
- Captures the current viewport without user interaction.
- Uses the active tab’s visible dimensions to compute the capture rectangle.

User interaction pattern:
- User selects “Visible area” from the popup.
- The background script ensures the content script is ready.
- The content script computes the visible rectangle and captures pixels.

Implementation highlights:
- Queries the active tab’s viewport metrics.
- Renders no overlays; proceeds directly to capture.
- Sends image data to the preview page.

Practical example:
- A user wants a quick screenshot of the current browser window content.

Limitations:
- Does not capture off-screen content below the fold.
- Not suitable for long pages requiring scroll capture.

Performance considerations:
- Minimal DOM manipulation; fast execution.
- Prefer lower resolution or compression for large viewports.

Quality optimization:
- Adjust capture quality parameters if supported by the underlying API.
- Consider throttling repeated captures to avoid UI jank.

**Section sources**
- [popup.js](file://popup.js)
- [background.js](file://background.js)
- [content.js](file://content.js)
- [preview.js](file://preview.js)

### Interactive Area Selection with Crosshair and Selection Box
Overview:
- Allows the user to select a rectangular region via mouse interactions.
- Displays a crosshair and a draggable/resizable selection box overlay.

User interaction pattern:
- User selects “Selection” from the popup.
- The content script injects overlays and listens for pointer events.
- Crosshair appears under the cursor; user drags to define the selection box.
- On release, the selection rectangle is finalized and capture proceeds.

Implementation highlights:
- Adds overlay elements to the page for crosshair and selection box.
- Tracks mouse move/drag events to update the selection box geometry.
- Computes the final rectangle in page coordinates and captures the region.

Practical example:
- A user wants to capture a specific element or portion of the page.

Limitations:
- Requires user precision; small targets may be difficult to select.
- Overlays may conflict with page styles or z-index.

Performance considerations:
- Overlay rendering is lightweight but can cause layout reflows if not optimized.
- Debounce pointer events to reduce frequent updates.

Quality optimization:
- Use crisp overlay lines and semi-transparent fills for visibility.
- Ensure overlays are positioned above page content without disrupting layout.

**Section sources**
- [content.js](file://content.js)
- [content.css](file://content.css)

### Intelligent Scroll Capture with Overlap Detection and Frozen Header Handling
Overview:
- Captures long pages by scrolling and stitching multiple screenshots.
- Detects overlapping regions to avoid duplication and align images precisely.
- Supports frozen/fixed headers by capturing them once and tiling them across segments.

User interaction pattern:
- User selects “Scroll capture” from the popup.
- The content script measures the total scrollable height and viewport.
- It calculates segment boundaries and overlap thresholds.
- Captures segments, aligns them using overlap detection, and merges them.
- Optionally captures a frozen header once and applies it to subsequent segments.

Implementation highlights:
- Measures document height and viewport height.
- Computes segment heights considering overlap thresholds.
- Uses overlap detection to align images vertically.
- Applies frozen header logic to maintain continuity across segments.

Practical example:
- A user wants a full-page screenshot of a long article or form.

Limitations:
- Performance scales with page length; very long pages may take significant time.
- Complex layouts with dynamic content may affect alignment accuracy.
- Frozen header detection relies on CSS positioning; sticky/floating headers may require manual adjustments.

Performance considerations:
- Limit segment height to balance memory and processing time.
- Use efficient image composition and minimal recomputation.
- Consider pausing capture during rapid scroll events.

Quality optimization:
- Increase overlap threshold for pages with subtle vertical movement.
- Optimize frozen header detection by targeting fixed-positioned elements.
- Compress intermediate images to reduce memory usage.

**Section sources**
- [content.js](file://content.js)

### Selection-Based Capture Using A1 Notation Parsing
Overview:
- Parses spreadsheet-style cell references (e.g., A1, B2:C5) to select regions.
- Converts A1 notation into page coordinates and captures the resulting rectangle.

User interaction pattern:
- User selects “A1 selection” from the popup and optionally enters a range.
- The content script parses the notation and resolves positions.
- Displays a temporary selection overlay and captures the region.

Implementation highlights:
- Parses A1 notation into row/column indices.
- Resolves cell boundaries to page coordinates.
- Captures the computed rectangle and removes overlays.

Practical example:
- A user wants to capture a specific table cell or range in a spreadsheet-like layout.

Limitations:
- Assumes a grid-like layout aligned with A1 notation semantics.
- May fail on irregular or non-uniform grids.

Performance considerations:
- Parsing and coordinate resolution are lightweight.
- Avoid frequent re-parsing by caching resolved ranges.

Quality optimization:
- Validate notation input and provide helpful error messages.
- Ensure overlay visibility over complex backgrounds.

**Section sources**
- [content.js](file://content.js)

## Dependency Analysis
The capture modes depend on coordinated messaging and shared UI components:
- popup.js depends on background.js for tab management and message routing.
- background.js depends on manifest permissions to inject content scripts.
- content.js depends on DOM APIs and overlay styles to render selections.
- preview.js depends on receiving image data from content.js.

```mermaid
graph TB
Popup["popup.js"] --> BG["background.js"]
BG --> Content["content.js"]
Content --> Preview["preview.js"]
Content --> CSS["content.css"]
Manifest["manifest.json"] --> BG
PopupHTML["popup.html"] --> Popup
PreviewHTML["preview.html"] --> Preview
```

**Diagram sources**
- [popup.js](file://popup.js)
- [background.js](file://background.js)
- [content.js](file://content.js)
- [preview.js](file://preview.js)
- [content.css](file://content.css)
- [manifest.json](file://manifest.json)
- [popup.html](file://popup.html)
- [preview.html](file://preview.html)

**Section sources**
- [popup.js](file://popup.js)
- [background.js](file://background.js)
- [content.js](file://content.js)
- [preview.js](file://preview.js)
- [content.css](file://content.css)
- [manifest.json](file://manifest.json)
- [popup.html](file://popup.html)
- [preview.html](file://preview.html)

## Performance Considerations
- Minimize DOM overlays and repaints during selection.
- Use efficient image composition and consider tiling for large scroll captures.
- Cache parsed A1 ranges and computed rectangles to avoid repeated work.
- Throttle pointer events and scroll handlers to prevent excessive updates.
- Compress captured images to reduce memory and transfer overhead.
- Consider pausing capture while the user is actively interacting to improve responsiveness.

## Troubleshooting Guide
Common issues and resolutions:
- Overlays not appearing:
  - Verify overlay styles are loaded and applied.
  - Ensure the content script is injected and active.
- Selection box not resizing:
  - Confirm pointer event listeners are attached and not blocked by page overlays.
- Scroll capture misalignment:
  - Increase overlap threshold for pages with subtle movement.
  - Re-check frozen header detection logic.
- A1 notation errors:
  - Validate input format and handle unsupported ranges gracefully.
- Long page capture timeouts:
  - Reduce segment height or enable compression.
  - Consider aborting and retrying with smaller batches.

**Section sources**
- [content.js](file://content.js)
- [content.css](file://content.css)
- [preview.js](file://preview.js)

## Conclusion
The extension supports multiple capture modes tailored to different use cases:
- Visible area capture for quick viewport screenshots.
- Interactive selection for precise region capture with visual feedback.
- Intelligent scroll capture for long pages with overlap-aware stitching and frozen header support.
- A1-based selection for spreadsheet-like layouts.

By understanding the implementation details, user interaction patterns, and performance considerations, users can choose the most appropriate mode and optimize results for their workflows.