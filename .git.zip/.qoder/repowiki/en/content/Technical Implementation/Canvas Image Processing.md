# Canvas Image Processing

<cite>
**Referenced Files in This Document**
- [background.js](file://background.js)
- [content.js](file://content.js)
- [preview.js](file://preview.js)
- [popup.js](file://popup.js)
- [content.css](file://content.css)
- [popup.html](file://popup.html)
- [preview.html](file://preview.html)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document describes a browser extension that performs Canvas-based image processing for capturing and stitching scrollable web pages. It focuses on high-DPI display support, canvas sizing strategies, pixel density handling, image cropping, canvas drawing operations, ImageData manipulation, and multi-frame stitching with overlap detection and alignment. It also covers performance optimization techniques for large images, memory management strategies, and browser compatibility considerations for Canvas operations.

## Project Structure
The extension consists of:
- Background script: orchestrates tab capture and communication with content scripts
- Content script: executes in page context to capture DOM regions and render to Canvas
- Preview script: manages the preview UI and image export
- Popup script and UI: user controls for capture options
- Stylesheet: CSS for overlay and preview UI
- HTML pages: popup and preview UI surfaces

```mermaid
graph TB
subgraph "Extension"
BG["background.js"]
CS["content.js"]
PV["preview.js"]
POP["popup.js"]
CSS["content.css"]
POPHTML["popup.html"]
PREVHTML["preview.html"]
end
subgraph "Web Page"
TAB["Tab"]
end
BG --> CS
CS --> TAB
BG --> PV
POP --> BG
POPHTML --> POP
PREVHTML --> PV
CSS --> POP
CSS --> PV
```

**Diagram sources**
- [background.js](file://background.js)
- [content.js](file://content.js)
- [preview.js](file://preview.js)
- [popup.js](file://popup.js)
- [content.css](file://content.css)
- [popup.html](file://popup.html)
- [preview.html](file://preview.html)

**Section sources**
- [background.js](file://background.js)
- [content.js](file://content.js)
- [preview.js](file://preview.js)
- [popup.js](file://popup.js)
- [content.css](file://content.css)
- [popup.html](file://popup.html)
- [preview.html](file://preview.html)

## Core Components
- Background script: coordinates capture lifecycle, requests screenshots from the content script, and manages result delivery to the preview UI
- Content script: runs in page context to compute element rectangles, render DOM regions to Canvas, handle high-DPI scaling, and return processed frames
- Preview script: displays captured frames, stitches frames into a single image, and exports the result
- Popup script/UI: provides user controls for capture mode and options
- CSS: overlays and styling for selection and preview UI

Key Canvas-related responsibilities:
- High-DPI compensation using device pixel ratio
- Canvas sizing and scaling to preserve visual quality
- Drawing DOM regions and images onto Canvas
- ImageData manipulation for cropping and compositing
- Multi-frame stitching with overlap detection and alignment

**Section sources**
- [background.js](file://background.js)
- [content.js](file://content.js)
- [preview.js](file://preview.js)
- [popup.js](file://popup.js)
- [content.css](file://content.css)

## Architecture Overview
The extension uses a multi-process architecture:
- The background script requests capture actions and receives frames
- The content script renders frames to Canvas and returns image data
- The preview script composes frames into a single stitched image

```mermaid
sequenceDiagram
participant User as "User"
participant Popup as "popup.js"
participant BG as "background.js"
participant CS as "content.js"
participant PV as "preview.js"
User->>Popup : "Start capture"
Popup->>BG : "Request capture"
BG->>CS : "Capture frame(s)"
CS->>CS : "Compute element rects<br/>Render to Canvas<br/>Apply device pixel ratio"
CS-->>BG : "Frame data (ImageData)"
BG->>PV : "Send frames"
PV->>PV : "Stitch frames<br/>Detect overlaps<br/>Align frames"
PV-->>User : "Preview and export"
```

**Diagram sources**
- [background.js](file://background.js)
- [content.js](file://content.js)
- [preview.js](file://preview.js)
- [popup.js](file://popup.js)

## Detailed Component Analysis

### High-DPI Display Support and Canvas Sizing
High-DPI displays require compensating for device pixel ratio to avoid blurry output. The content script computes the device pixel ratio and scales the canvas backing store while keeping the CSS layout size constant. This ensures crisp rendering on Retina and high-resolution screens.

Implementation highlights:
- Detect device pixel ratio and scale canvas width/height accordingly
- Scale drawing operations by the same factor
- Preserve visual CSS size for layout stability

```mermaid
flowchart TD
Start(["Start Rendering"]) --> GetDPR["Get devicePixelRatio"]
GetDPR --> ComputeScaled["Compute scaled width/height"]
ComputeScaled --> SetBacking["Set canvas backing store size"]
SetBacking --> ScaleContext["Scale 2D context by DPR"]
ScaleContext --> DrawOps["Perform drawing operations"]
DrawOps --> Export["Export frame"]
```

**Diagram sources**
- [content.js](file://content.js)

**Section sources**
- [content.js](file://content.js)

### Canvas Sizing Strategies and Pixel Density Handling
Canvas sizing involves two distinct sizes:
- CSS size: controls the visual layout and scaling in the document
- Backing store size: controls the actual pixel resolution

Pixel density handling:
- Multiply logical pixel dimensions by device pixel ratio for backing store
- Scale drawing operations to match the backing store
- Ensure ImageData reflects the correct pixel count for cropping and export

```mermaid
classDiagram
class Canvas {
+number width
+number height
+number backingWidth
+number backingHeight
+number dpr
+scaleContext(factor) void
+drawImage(image, x, y) void
+getImageData(x, y, w, h) ImageData
}
```

**Diagram sources**
- [content.js](file://content.js)

**Section sources**
- [content.js](file://content.js)

### Image Cropping Algorithms
Cropping is performed using ImageData to extract rectangular regions from rendered frames. The algorithm:
- Computes crop rectangle in logical pixels
- Converts to backing-store coordinates using device pixel ratio
- Extracts ImageData for the region
- Optionally applies color adjustments or filters

```mermaid
flowchart TD
CropStart["Crop Request"] --> LogicalRect["Compute logical crop rect"]
LogicalRect --> ConvertCoords["Convert to backing-store coords"]
ConvertCoords --> Extract["Extract ImageData"]
Extract --> PostProcess["Optional post-processing"]
PostProcess --> Output["Return cropped frame"]
```

**Diagram sources**
- [content.js](file://content.js)

**Section sources**
- [content.js](file://content.js)

### Canvas Drawing Operations and ImageData Manipulation
Drawing operations:
- Render DOM regions to Canvas using 2D context
- Composite multiple frames by drawing onto a master canvas
- Use ImageData for low-level pixel manipulation when needed

ImageData manipulation:
- Access raw pixel arrays for cropping and compositing
- Apply transformations (e.g., alpha blending, color adjustments)
- Compose frames by copying ImageData blocks into a target buffer

```mermaid
sequenceDiagram
participant CS as "content.js"
participant Ctx as "Canvas 2D Context"
participant ID as "ImageData"
CS->>Ctx : "createImageData(width,height)"
CS->>ID : "fill pixels"
CS->>Ctx : "putImageData(ID, dx, dy)"
CS->>ID : "getImageData(x,y,w,h)"
CS->>ID : "manipulate pixel data"
CS->>Ctx : "putImageData(ID, dx, dy)"
```

**Diagram sources**
- [content.js](file://content.js)

**Section sources**
- [content.js](file://content.js)

### Multi-Frame Stitching for Scroll Captures
Stitching multiple frames into a single image:
- Capture frames at intervals equal to the viewport height minus overlap
- Detect overlaps by comparing vertical positions and detecting repeated content
- Align frames by translating subsequent frames to minimize seam artifacts
- Composite frames onto a master canvas sized to total height and maximum width

Overlap detection and alignment:
- Compare top/bottom edges of adjacent frames
- Compute vertical offset to align seams
- Use sliding window technique to refine alignment

```mermaid
flowchart TD
Frames["Captured Frames"] --> ComputeOverlap["Compute overlap candidates"]
ComputeOverlap --> AlignFrames["Align frames vertically"]
AlignFrames --> Composite["Composite onto master canvas"]
Composite --> Export["Export stitched image"]
```

**Diagram sources**
- [preview.js](file://preview.js)

**Section sources**
- [preview.js](file://preview.js)

### Performance Optimization Techniques for Large Images
Large image processing requires careful resource management:
- Use offscreen canvases to avoid blocking the UI thread
- Process frames incrementally and dispose of intermediate buffers
- Limit ImageData operations to necessary regions
- Prefer drawing operations over pixel-level manipulations when possible
- Use efficient data structures for overlap detection (e.g., spatial indexing)

Memory management:
- Dispose of ImageData and canvas resources after use
- Avoid retaining references to large buffers
- Stream frames to reduce peak memory usage

Browser compatibility:
- Feature-detect devicePixelRatio and 2D context capabilities
- Provide fallbacks for unsupported APIs
- Test across major browsers and adjust behavior accordingly

**Section sources**
- [content.js](file://content.js)
- [preview.js](file://preview.js)

## Dependency Analysis
The extension components depend on each other as follows:
- Background script depends on content script for frame data
- Preview script depends on background script for received frames
- Popup script triggers background script actions
- CSS stylesheets support overlay and preview UI

```mermaid
graph LR
Popup["popup.js"] --> BG["background.js"]
BG --> CS["content.js"]
BG --> PV["preview.js"]
CSS["content.css"] --> Popup
CSS --> PV
POPHTML["popup.html"] --> Popup
PREVHTML["preview.html"] --> PV
```

**Diagram sources**
- [background.js](file://background.js)
- [content.js](file://content.js)
- [preview.js](file://preview.js)
- [popup.js](file://popup.js)
- [content.css](file://content.css)
- [popup.html](file://popup.html)
- [preview.html](file://preview.html)

**Section sources**
- [background.js](file://background.js)
- [content.js](file://content.js)
- [preview.js](file://preview.js)
- [popup.js](file://popup.js)
- [content.css](file://content.css)
- [popup.html](file://popup.html)
- [preview.html](file://preview.html)

## Performance Considerations
- Offscreen canvases: Perform heavy rendering off the main thread to keep UI responsive
- Incremental processing: Process and export frames progressively to reduce memory pressure
- Efficient ImageData usage: Minimize allocations and copies; reuse buffers when possible
- Canvas sizing: Use appropriate backing store sizes to balance quality and performance
- Browser-specific optimizations: Tailor performance strategies to detected capabilities

## Troubleshooting Guide
Common issues and resolutions:
- Blurry output on high-DPI displays: Verify device pixel ratio compensation and backing store scaling
- Memory errors with large images: Ensure ImageData and canvas resources are disposed; process frames incrementally
- Incorrect frame alignment: Validate overlap detection logic and coordinate conversions
- Cross-origin restrictions: Handle CORS errors when drawing images from external domains
- Compatibility problems: Feature-detect APIs and provide graceful degradation

**Section sources**
- [content.js](file://content.js)
- [preview.js](file://preview.js)

## Conclusion
This extension demonstrates a robust Canvas-based image processing pipeline for scroll captures. By implementing high-DPI compensation, precise canvas sizing, efficient ImageData manipulation, and multi-frame stitching with overlap detection, it achieves high-quality output suitable for large-scale web page captures. Proper performance optimization and memory management ensure reliable operation across diverse environments and browser configurations.