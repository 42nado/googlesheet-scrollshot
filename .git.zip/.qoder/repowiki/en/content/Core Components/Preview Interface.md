# Preview Interface

<cite>
**Referenced Files in This Document**
- [preview.html](file://preview.html)
- [preview.js](file://preview.js)
- [background.js](file://background.js)
- [content.js](file://content.js)
- [popup.js](file://popup.js)
- [manifest.json](file://manifest.json)
- [content.css](file://content.css)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document describes the preview interface component of the extension, focusing on the HTML structure and user interface elements, JavaScript functionality for zoom operations and navigation, copy-to-clipboard integration, download coordination, image manipulation, preview state management, and user interaction handling. It also covers integration with background script data storage, error handling, and responsive design considerations, with examples of the complete workflow from screenshot capture to final image export.

## Project Structure
The preview interface consists of:
- preview.html: Defines the UI layout and styles for the preview window.
- preview.js: Implements preview state, zoom controls, panning, keyboard shortcuts, copy-to-clipboard, and download coordination.
- background.js: Provides messaging handlers for capture, preview launch, and downloads.
- content.js: Implements capture modes and image processing, sending results to the preview.
- popup.js: Triggers capture actions and injects content scripts.
- manifest.json: Declares permissions, background service worker, and web-accessible resources.
- content.css: Overlay styles for selection capture.

```mermaid
graph TB
subgraph "UI Layer"
PH["preview.html"]
PJ["preview.js"]
end
subgraph "Background Layer"
BG["background.js"]
end
subgraph "Content Layer"
CT["content.js"]
PC["popup.js"]
end
subgraph "Manifest"
MF["manifest.json"]
end
PC --> CT
CT --> BG
BG --> PJ
MF --> PH
MF --> PJ
```

**Diagram sources**
- [preview.html:1-147](file://preview.html#L1-L147)
- [preview.js:1-180](file://preview.js#L1-L180)
- [background.js:1-47](file://background.js#L1-L47)
- [content.js:1-795](file://content.js#L1-L795)
- [popup.js:1-47](file://popup.js#L1-L47)
- [manifest.json:1-34](file://manifest.json#L1-L34)

**Section sources**
- [preview.html:1-147](file://preview.html#L1-L147)
- [preview.js:1-180](file://preview.js#L1-L180)
- [background.js:1-47](file://background.js#L1-L47)
- [content.js:1-795](file://content.js#L1-L795)
- [popup.js:1-47](file://popup.js#L1-L47)
- [manifest.json:1-34](file://manifest.json#L1-L34)

## Core Components
- Preview UI Elements:
  - Toolbar with filename display, dimensions display, copy-to-clipboard button, download button, and zoom controls.
  - Preview area containing the image with fit and zoomed modes.
- Preview State Management:
  - Tracks data URL, filename, zoom percentage, fit mode, dragging state, and mouse positions for panning.
- Interaction Handling:
  - Zoom in/out/reset via buttons and keyboard shortcuts (Ctrl+Plus/Ctrl+Minus/Ctrl+0).
  - Pan by dragging in zoomed mode.
  - Copy image to clipboard using Clipboard API with fallback handling.
  - Download via background script with timestamped filenames.

**Section sources**
- [preview.html:129-143](file://preview.html#L129-L143)
- [preview.js:13-22](file://preview.js#L13-L22)
- [preview.js:62-111](file://preview.js#L62-L111)
- [preview.js:117-141](file://preview.js#L117-L141)
- [preview.js:143-179](file://preview.js#L143-L179)

## Architecture Overview
The preview workflow spans content scripts, background script, and the preview UI:

```mermaid
sequenceDiagram
participant User as "User"
participant Popup as "popup.js"
participant Content as "content.js"
participant Background as "background.js"
participant Preview as "preview.js"
User->>Popup : Click capture action
Popup->>Content : Inject content script and CSS
Popup->>Content : Send capture action
Content->>Background : Request capture-visible
Background-->>Content : Return data URL
Content->>Background : Request preview with data URL and filename
Background->>Preview : Open preview.html and store previewData
Preview->>Preview : Load previewData and display image
User->>Preview : Interact (copy/download/zoom/pan)
Preview->>Background : Request download
Background-->>Preview : Confirm download
```

**Diagram sources**
- [popup.js:10-44](file://popup.js#L10-L44)
- [content.js:25-43](file://content.js#L25-L43)
- [background.js:26-33](file://background.js#L26-L33)
- [background.js:26-33](file://background.js#L26-L33)
- [preview.js:24-32](file://preview.js#L24-L32)
- [preview.js:58-60](file://preview.js#L58-L60)
- [background.js:35-45](file://background.js#L35-L45)

## Detailed Component Analysis

### Preview HTML Structure and UI Elements
- Layout:
  - Toolbar with filename, dimensions, copy, download, and zoom controls.
  - Preview area with two modes: fit (contain) and zoomed (manual sizing).
- Styling:
  - Dark theme with blue accents.
  - Responsive flex layout with overflow handling.
  - Fit mode applies max-width/max-height with object-fit: contain.
  - Zoomed mode enables panning and drag cursor.

**Section sources**
- [preview.html:129-143](file://preview.html#L129-L143)
- [preview.html:65-126](file://preview.html#L65-L126)

### Preview JavaScript Functionality
- State Initialization:
  - Loads preview data from local storage, sets filename and image source, removes stored data.
  - Computes natural dimensions on image load.
- Zoom Operations:
  - Zoom in/out by 25% increments, clamped between 25% and 400%.
  - Reset to 100% and fit mode.
  - Fit mode toggles between fit and zoomed; calculates effective zoom from display size.
  - Applies CSS classes and inline styles to switch modes.
- Keyboard Shortcuts:
  - Ctrl+Plus/Ctrl+Minus/Ctrl+0 trigger zoom in/out/reset.
- Mouse Interaction:
  - Ctrl+Scroll wheel zooms in/out.
  - Drag-and-pan in zoomed mode using mousedown/mousemove/mouseup.
- Copy-to-Clipboard:
  - Fetches image data URL as Blob, writes ClipboardItem with type, and updates button text temporarily.
  - Catches and logs errors.
- Download Coordination:
  - Sends message to background script with data URL and filename.
  - Background script triggers chrome.downloads.download with saveAs prompt.

```mermaid
flowchart TD
Start(["Preview Loaded"]) --> LoadData["Load previewData from storage"]
LoadData --> SetImage["Set filename and image src"]
SetImage --> OnLoad["On image load<br/>Compute natural dimensions"]
OnLoad --> ApplyZoom["Apply zoom state"]
ApplyZoom --> UserAction{"User Action?"}
UserAction --> |Zoom Buttons| ZoomOps["Zoom in/out/reset"]
UserAction --> |Keyboard| KeyZoom["Ctrl+ +/- / 0"]
UserAction --> |Mouse Wheel| WheelZoom["Ctrl+Wheel"]
UserAction --> |Drag| DragPan["Drag to pan"]
ZoomOps --> ApplyZoom
KeyZoom --> ApplyZoom
WheelZoom --> ApplyZoom
DragPan --> ApplyZoom
UserAction --> |Copy| CopyBlob["Fetch Blob and write ClipboardItem"]
UserAction --> |Download| SendMsg["Send download message"]
CopyBlob --> End(["Done"])
SendMsg --> End
```

**Diagram sources**
- [preview.js:24-37](file://preview.js#L24-L37)
- [preview.js:62-111](file://preview.js#L62-L111)
- [preview.js:117-141](file://preview.js#L117-L141)
- [preview.js:143-179](file://preview.js#L143-L179)
- [preview.js:39-55](file://preview.js#L39-L55)
- [preview.js:58-60](file://preview.js#L58-L60)

**Section sources**
- [preview.js:13-37](file://preview.js#L13-L37)
- [preview.js:62-111](file://preview.js#L62-L111)
- [preview.js:117-141](file://preview.js#L117-L141)
- [preview.js:143-179](file://preview.js#L143-L179)
- [preview.js:39-55](file://preview.js#L39-L55)
- [preview.js:58-60](file://preview.js#L58-L60)

### Background Script Integration
- Preview Launch:
  - Receives preview message with data URL and filename, stores in local storage, opens preview.html.
- Download:
  - Receives download message, triggers chrome.downloads.download with saveAs prompt and returns download ID.

**Section sources**
- [background.js:26-33](file://background.js#L26-L33)
- [background.js:35-45](file://background.js#L35-L45)

### Content Script Capture and Image Processing
- Capture Modes:
  - Visible screenshot, area selection, tall scroll capture, and selection capture.
- Image Processing:
  - Cropping to rectangle with device pixel ratio consideration.
  - Vertical stitching with overlap detection and frozen header handling.
  - Duplicate frame detection to stop capture early.
- Filename Generation:
  - Timestamped PNG filenames for each capture mode.

**Section sources**
- [content.js:25-43](file://content.js#L25-L43)
- [content.js:47-136](file://content.js#L47-L136)
- [content.js:140-289](file://content.js#L140-L289)
- [content.js:293-469](file://content.js#L293-L469)
- [content.js:512-529](file://content.js#L512-L529)
- [content.js:531-574](file://content.js#L531-L574)
- [content.js:670-688](file://content.js#L670-L688)

### Popup Integration
- Triggers capture actions, injects content script and CSS, sends messages to content script, and closes itself.

**Section sources**
- [popup.js:10-44](file://popup.js#L10-L44)

### Manifest Permissions and Web Access
- Permissions include activeTab, scripting, downloads, tabs, and storage.
- Web-accessible resource exposes preview.html for background script to open.

**Section sources**
- [manifest.json:6](file://manifest.json#L6)
- [manifest.json:24-27](file://manifest.json#L24-L27)

### Selection Overlay Styles
- Overlay and selection visuals for area capture mode.

**Section sources**
- [content.css:1-35](file://content.css#L1-L35)

## Dependency Analysis
- preview.js depends on:
  - Local storage for preview data.
  - Clipboard API for copy-to-clipboard.
  - Runtime messaging for download coordination.
  - DOM elements for UI state and interactions.
- background.js depends on:
  - Tabs capture for visible tab images.
  - Downloads API for saving images.
  - Storage for temporary preview data.
- content.js depends on:
  - Messaging with background script for capture and preview.
  - Canvas APIs for cropping and stitching.
  - DOM discovery helpers for Google Sheets elements.

```mermaid
graph LR
PJ["preview.js"] --> LS["chrome.storage.local"]
PJ --> CB["navigator.clipboard"]
PJ --> RT["chrome.runtime"]
BG["background.js"] --> TC["chrome.tabs.captureVisibleTab"]
BG --> DL["chrome.downloads.download"]
BG --> ST["chrome.storage.local"]
CT["content.js"] --> RT
CT --> CAN["Canvas APIs"]
CT --> DOM["DOM Discovery"]
```

**Diagram sources**
- [preview.js:24-32](file://preview.js#L24-L32)
- [preview.js:40-55](file://preview.js#L40-L55)
- [preview.js:58-60](file://preview.js#L58-L60)
- [background.js:9-18](file://background.js#L9-L18)
- [background.js:37-43](file://background.js#L37-L43)
- [background.js:28-31](file://background.js#L28-L31)
- [content.js:105-124](file://content.js#L105-L124)
- [content.js:276-283](file://content.js#L276-L283)

**Section sources**
- [preview.js:24-60](file://preview.js#L24-L60)
- [background.js:1-47](file://background.js#L1-L47)
- [content.js:1-9](file://content.js#L1-L9)

## Performance Considerations
- Zoom and Pan:
  - Switching between fit and zoomed modes uses CSS classes and inline styles; avoid frequent reflows by batching DOM updates.
  - Drag panning uses scrollLeft/scrollTop updates; consider throttling mousemove events for smoother performance.
- Copy-to-Clipboard:
  - Fetching Blob and writing ClipboardItem is asynchronous; keep UI feedback short-lived.
- Downloads:
  - Background download uses chrome.downloads.download with saveAs; ensure data URLs are valid and accessible.
- Image Processing:
  - Cropping and stitching operate on ImageData and Canvas; consider reducing sampling steps for large images to improve responsiveness.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
- Copy-to-Clipboard Fails:
  - The preview attempts to write a ClipboardItem with the image Blob. If it fails, the error is logged; ensure HTTPS context and Clipboard API availability.
- Download Does Not Start:
  - Verify that the background script receives the download message and that chrome.downloads.download is permitted by permissions.
- Preview Not Loading Image:
  - Ensure previewData is set in storage before opening preview.html and that the data URL is valid.
- Zoom Controls Disabled:
  - Zoom buttons and keyboard shortcuts require the preview window to be focused; ensure no modal overlays prevent interaction.
- Drag Panning Not Working:
  - Dragging requires zoomed mode; confirm that the preview area has the zoomed class and that mouse events are not intercepted by buttons.

**Section sources**
- [preview.js:40-55](file://preview.js#L40-L55)
- [preview.js:58-60](file://preview.js#L58-L60)
- [background.js:26-33](file://background.js#L26-L33)
- [background.js:35-45](file://background.js#L35-L45)

## Conclusion
The preview interface provides a streamlined, responsive experience for reviewing captured images with robust zoom controls, keyboard shortcuts, copy-to-clipboard integration, and coordinated downloads. Its architecture cleanly separates concerns across content, background, and UI layers, enabling reliable workflows from capture to export. Proper handling of state, user interactions, and error conditions ensures a smooth user experience across capture modes and image sizes.