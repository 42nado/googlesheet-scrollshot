# Scroll Capture (Tall)

<cite>
**Referenced Files in This Document**
- [content.js](file://content.js)
- [background.js](file://background.js)
- [manifest.json](file://manifest.json)
- [popup.js](file://popup.js)
- [popup.html](file://popup.html)
- [preview.js](file://preview.js)
- [preview.html](file://preview.html)
- [content.css](file://content.css)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the intelligent scroll capture mode designed for tall Google Sheets. It covers the multi-method scrolling approach (wheel event simulation, direct scrollTop manipulation, and fallback mechanisms), the frame capture algorithm, overlap detection using detectFrozenHeader() and findVerticalOverlap(), and the vertical stitching process with stitchVertical(). It also documents frozen header handling, duplicate frame detection, quality assurance measures, performance optimizations, error handling, and how different scrolling methods adapt to various Google Sheets configurations.

## Project Structure
The extension consists of a Manifest v3 configuration, a content script that performs capture modes, a background service worker for tab capture and preview orchestration, and UI assets for the popup and preview pages.

```mermaid
graph TB
subgraph "Extension"
M["manifest.json"]
BG["background.js"]
POP["popup.html + popup.js"]
PRE["preview.html + preview.js"]
CS["content.js"]
CSS["content.css"]
end
M --> BG
M --> POP
M --> PRE
M --> CS
M --> CSS
POP --> CS
CS --> BG
BG --> PRE
```

**Diagram sources**
- [manifest.json:1-34](file://manifest.json#L1-L34)
- [background.js:1-47](file://background.js#L1-L47)
- [popup.html:1-147](file://popup.html#L1-L147)
- [popup.js:1-47](file://popup.js#L1-L47)
- [preview.html:1-147](file://preview.html#L1-L147)
- [preview.js:1-180](file://preview.js#L1-L180)
- [content.js:1-795](file://content.js#L1-L795)
- [content.css:1-35](file://content.css#L1-L35)

**Section sources**
- [manifest.json:1-34](file://manifest.json#L1-L34)
- [popup.html:1-147](file://popup.html#L1-L147)
- [popup.js:1-47](file://popup.js#L1-L47)
- [preview.html:1-147](file://preview.html#L1-L147)
- [preview.js:1-180](file://preview.js#L1-L180)
- [content.js:1-795](file://content.js#L1-L795)
- [content.css:1-35](file://content.css#L1-L35)

## Core Components
- Tall capture entry point: startTallCapture()
- Multi-method scrolling: wheel events on canvas, direct scrollTop, wheel on container
- Frame capture pipeline: capture-visible -> cropToImageData -> duplicate detection
- Overlap detection: detectFrozenHeader() and findVerticalOverlap()
- Vertical stitching: stitchVertical()
- Selection capture mode: startSelectionCapture() with early termination on scrolled-past-selection
- Background orchestration: capture-visible, preview, download

**Section sources**
- [content.js:140-289](file://content.js#L140-L289)
- [content.js:293-469](file://content.js#L293-L469)
- [content.js:531-574](file://content.js#L531-L574)
- [content.js:640-668](file://content.js#L640-L668)
- [content.js:576-638](file://content.js#L576-L638)
- [background.js:1-47](file://background.js#L1-L47)

## Architecture Overview
The tall capture mode orchestrates a loop of:
- Capturing the visible tab
- Cropping to the grid area
- Detecting duplicates
- Scrolling using multiple strategies
- Detecting overlap and stitching frames vertically

```mermaid
sequenceDiagram
participant User as "User"
participant Popup as "popup.js"
participant Content as "content.js"
participant BG as "background.js"
participant Preview as "preview.html/js"
User->>Popup : Click "Scroll Capture"
Popup->>Content : sendMessage({action : "tall"})
Content->>BG : capture-visible (retry up to 3x)
BG-->>Content : dataUrl
Content->>Content : cropToImageData(gridRect)
Content->>Content : detectFrozenHeader()
Content->>Content : findVerticalOverlap()
Content->>Content : stitchVertical(prev,next,delta)
Content->>BG : preview({dataUrl,filename})
BG-->>Preview : open preview.html
Preview-->>User : display stitched image
```

**Diagram sources**
- [popup.js:10-38](file://popup.js#L10-L38)
- [content.js:140-289](file://content.js#L140-L289)
- [background.js:2-24](file://background.js#L2-L24)
- [preview.html:1-147](file://preview.html#L1-L147)
- [preview.js:24-32](file://preview.js#L24-L32)

## Detailed Component Analysis

### Tall Capture Mode: startTallCapture()
- Resets scrollTop to top, waits, and initializes counters for duplicate frames and no-scroll detection.
- Captures frames with a short initial delay, then a steady delay between frames.
- Crops each capture to the grid rectangle determined by findGridCanvasRect().
- Detects duplicate frames using framesAreIdentical() and stops after a threshold.
- Scrolls using three methods in order:
  1) WheelEvent on the largest visible canvas
  2) Direct scrollTop on the scroll measurement element
  3) WheelEvent on the grid container
- After each scroll attempt, checks if scrollTop changed; if not, increments consecutiveNoScroll and stops after a threshold.
- Computes lastDeltaPx from the measured scroll offset multiplied by devicePixelRatio.
- Stitches frames using stitchVertical() and sends the final image to preview.

```mermaid
flowchart TD
Start(["startTallCapture"]) --> Reset["Reset scrollTop<br/>Wait"]
Reset --> Loop{"Frame < maxFrames<br/>and not cancelled"}
Loop --> |Yes| Capture["Capture visible tab"]
Capture --> Crop["Crop to grid rectangle"]
Crop --> DupCheck{"Duplicate frame?"}
DupCheck --> |Yes| IncDup["Increment consecutiveDuplicates"]
IncDup --> StopDup{">= 3 duplicates?"}
StopDup --> |Yes| End["Stop capture"]
StopDup --> |No| Scroll["Scroll attempt (3 methods)"]
DupCheck --> |No| Scroll
Scroll --> NoScroll{"scrollTop changed?"}
NoScroll --> |No| IncNS["Increment consecutiveNoScroll"]
IncNS --> StopNS{">= 3 no-scroll?"}
StopNS --> |Yes| End
StopNS --> |No| Next["Compute lastDeltaPx"]
NoScroll --> |Yes| Next
Next --> Loop
Loop --> |No| End
End --> Stitch["stitchVertical(prev,next,lastDeltaPx)"]
Stitch --> Preview["Send to preview"]
```

**Diagram sources**
- [content.js:140-289](file://content.js#L140-L289)
- [content.js:531-574](file://content.js#L531-L574)

**Section sources**
- [content.js:140-289](file://content.js#L140-L289)

### Multi-Method Scrolling
- Method 1: WheelEvent on the largest visible canvas inside the grid area. Selects the canvas with the largest area intersecting the viewport.
- Method 2: Direct scrollTop on the scroll measurement element (e.g., native scrollbar element) as a fallback.
- Method 3: WheelEvent on the grid container as a last resort.
- After each method, the code checks scrollTop before and after to decide whether to continue scrolling or stop.

```mermaid
flowchart TD
S(["Scroll Attempt"]) --> WheelCanvas["Dispatch wheel on largest canvas"]
WheelCanvas --> Wait1["Wait for scroll"]
Wait1 --> Check1{"scrollTop changed?"}
Check1 --> |Yes| Done["Done"]
Check1 --> |No| Direct["Set scrollTop += step"]
Direct --> Wait2["Wait for scroll"]
Wait2 --> Check2{"scrollTop changed?"}
Check2 --> |Yes| Done
Check2 --> |No| WheelContainer["Dispatch wheel on container"]
WheelContainer --> Wait3["Wait for scroll"]
Wait3 --> Done
```

**Diagram sources**
- [content.js:206-244](file://content.js#L206-L244)

**Section sources**
- [content.js:206-244](file://content.js#L206-L244)

### Frame Capture Algorithm
- Uses the background service worker to capture the visible tab, retrying up to three times with a delay if the capture fails.
- Each capture is converted to an ImageData and cropped to the grid rectangle.
- The grid rectangle is derived from the largest visible canvas or a fallback rectangle.

```mermaid
sequenceDiagram
participant Content as "content.js"
participant BG as "background.js"
Content->>BG : capture-visible
BG->>BG : attempt capture
BG-->>Content : dataUrl (or retry)
Content->>Content : cropToImageData(dataUrl, gridRect, dpr)
```

**Diagram sources**
- [background.js:2-24](file://background.js#L2-L24)
- [content.js:512-529](file://content.js#L512-L529)

**Section sources**
- [background.js:2-24](file://background.js#L2-L24)
- [content.js:512-529](file://content.js#L512-L529)

### Overlap Detection and Frozen Header Handling
- detectFrozenHeader(): Scans the top rows of two frames to detect frozen headers by computing pixel-wise differences and counting matches. Returns the height of the frozen region.
- findVerticalOverlap(): Extracts a horizontal strip from the bottom of the previous frame and searches for the best vertical match in the next frame within a plausible range. Uses sampling to reduce cost and refines the result within a small window.
- stitchVertical(): Uses the detected frozen header height and overlap to compute the append start for the next frame. Falls back to expectedDeltaPx or a middle split if overlap detection fails.

```mermaid
flowchart TD
A["detectFrozenHeader(prev,next)"] --> FH["Return frozen header height"]
B["findVerticalOverlap(prev,next,stripH,expectedDeltaPx,frozenH)"] --> BestY["Best matching Y"]
C["stitchVertical(prev,next,lastDeltaPx)"] --> Overlap{"Overlap found?"}
Overlap --> |Yes| Append["Append next frame after overlap"]
Overlap --> |No| Fallback["Fallback to expectedDeltaPx or middle"]
Append --> Result["Return stitched ImageData"]
Fallback --> Result
```

**Diagram sources**
- [content.js:640-668](file://content.js#L640-L668)
- [content.js:576-638](file://content.js#L576-L638)
- [content.js:531-574](file://content.js#L531-L574)

**Section sources**
- [content.js:640-668](file://content.js#L640-L668)
- [content.js:576-638](file://content.js#L576-L638)
- [content.js:531-574](file://content.js#L531-L574)

### Duplicate Frame Detection
- framesAreIdentical(): Compares two frames by sampling pixels at regular intervals and computes a match ratio. If the ratio exceeds a threshold, the frames are considered duplicates. Used to stop capture when repeated frames appear.

**Section sources**
- [content.js:670-688](file://content.js#L670-L688)

### Selection Capture Mode (Related Behavior)
- startSelectionCapture() mirrors the tall capture loop but adds an early termination condition: hasScrolledPastSelection(range()) checks if selection highlights have scrolled above the viewport and stops capturing when true. It also uses the current grid rectangle for cropping during each frame.

**Section sources**
- [content.js:293-469](file://content.js#L293-L469)
- [content.js:779-794](file://content.js#L779-L794)

### DOM Discovery and Cropping
- findGridContainer(): Heuristically identifies the scrollable grid container by known selectors and scrollHeight/clientHeight thresholds, or by selecting the element with the largest area whose scrollHeight exceeds clientHeight.
- findGridCanvasRect(): Identifies the grid canvas with the largest area intersecting the viewport, or falls back to a rectangle near the top-left of the window.
- cropToImageData(): Converts a dataUrl to an Image, draws the specified rectangle scaled by devicePixelRatio, and returns ImageData.

**Section sources**
- [content.js:473-494](file://content.js#L473-L494)
- [content.js:496-508](file://content.js#L496-L508)
- [content.js:512-529](file://content.js#L512-L529)

### Preview and Download Pipeline
- background.js handles preview by storing the dataUrl in local storage and opening preview.html.
- preview.html/js displays the image, supports copy-to-clipboard, download, zoom, and panning.

**Section sources**
- [background.js:26-33](file://background.js#L26-L33)
- [preview.html:1-147](file://preview.html#L1-L147)
- [preview.js:24-60](file://preview.js#L24-L60)

## Dependency Analysis
- content.js depends on:
  - background.js for tab capture and preview orchestration
  - popup.js/popup.html for initiating capture
  - preview.html/js for displaying results
  - content.css for overlay visuals during area capture
- background.js depends on:
  - chrome.tabs.captureVisibleTab for screen capture
  - chrome.downloads for saving images
  - chrome.storage for preview data transport
- manifest.json defines permissions and content script injection for Google Sheets URLs.

```mermaid
graph LR
Popup["popup.js/html"] --> Content["content.js"]
Content --> BG["background.js"]
BG --> Preview["preview.html/js"]
Content --> CSS["content.css"]
Manifest["manifest.json"] --> Content
Manifest --> BG
Manifest --> Preview
```

**Diagram sources**
- [popup.js:10-38](file://popup.js#L10-L38)
- [content.js:140-289](file://content.js#L140-L289)
- [background.js:1-47](file://background.js#L1-L47)
- [preview.html:1-147](file://preview.html#L1-L147)
- [preview.js:24-32](file://preview.js#L24-L32)
- [content.css:1-35](file://content.css#L1-L35)
- [manifest.json:19-27](file://manifest.json#L19-L27)

**Section sources**
- [manifest.json:19-27](file://manifest.json#L19-L27)
- [popup.js:10-38](file://popup.js#L10-L38)
- [content.js:140-289](file://content.js#L140-L289)
- [background.js:1-47](file://background.js#L1-L47)
- [preview.html:1-147](file://preview.html#L1-L147)
- [preview.js:24-32](file://preview.js#L24-L32)
- [content.css:1-35](file://content.css#L1-L35)

## Performance Considerations
- Sampling and step sizes:
  - Overlap detection samples ~100 columns and steps by 2 for speed, then refines within ±5px.
  - Duplicate detection samples pixels at intervals proportional to total pixels to keep comparisons fast.
- Delay tuning:
  - Initial capture delay is longer to stabilize rendering, subsequent delays balance responsiveness and stability.
- Canvas-based scrolling:
  - Dispatching wheel events on the largest visible canvas reduces overhead compared to full DOM manipulation.
- Device pixel ratio:
  - Cropping and drawing use dpr to preserve sharpness on high-DPI displays.
- Early termination:
  - Duplicate frames and no-scroll thresholds prevent unnecessary captures.
- Retry on capture failure:
  - Background capture retries improve reliability under load.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
- No capture data:
  - The capture-visible action retries up to three times with a delay. If still failing, the content script surfaces an error.
- Scroll not progressing:
  - The code checks scrollTop before and after each scroll attempt. If unchanged, it tries the next method. If all methods fail, the loop stops after a threshold.
- Duplicate frames:
  - If three consecutive frames are identical, capture stops to avoid redundant stitching.
- Selection capture ending prematurely:
  - If selection highlights scroll above the viewport, capture stops early.
- Preview not opening:
  - Ensure the background service worker successfully stored preview data and opened preview.html.

**Section sources**
- [background.js:2-24](file://background.js#L2-L24)
- [content.js:176-182](file://content.js#L176-L182)
- [content.js:190-201](file://content.js#L190-L201)
- [content.js:385-389](file://content.js#L385-L389)
- [background.js:26-33](file://background.js#L26-L33)

## Conclusion
The tall capture mode combines robust frame capture, multi-strategy scrolling, and precise overlap detection to reliably stitch tall Google Sheets. The system adapts to different configurations by prioritizing wheel events on visible canvases, falling back to direct scrollTop manipulation and container wheel events. Quality assurance includes duplicate frame detection, frozen header handling, and fallback stitching logic. Performance is optimized through sampling, delays, and early termination, while the background service worker ensures reliable capture and preview delivery.