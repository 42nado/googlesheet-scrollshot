# Architecture Overview

<cite>
**Referenced Files in This Document**
- [manifest.json](file://manifest.json)
- [background.js](file://background.js)
- [content.js](file://content.js)
- [popup.js](file://popup.js)
- [popup.html](file://popup.html)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Security Model and Permissions](#security-model-and-permissions)
7. [Message Passing System](#message-passing-system)
8. [Data Flow Analysis](#data-flow-analysis)
9. [MV3 Migration Benefits](#mv3-migration-benefits)
10. [Architectural Constraints](#architectural-constraints)
11. [Performance Considerations](#performance-considerations)
12. [Troubleshooting Guide](#troubleshooting-guide)
13. [Conclusion](#conclusion)

## Introduction

This document provides a comprehensive architectural analysis of a Chrome Extension MV3 designed for Google Sheets screenshot functionality. The extension enables users to capture screenshots, area selections, and scroll captures of Google Sheets documents through an intuitive popup interface. The architecture follows Chrome Extension MV3 patterns with a service worker background script, content script injection, and popup interface components.

The extension operates by combining three distinct capture modes: standard screenshot capture, interactive area selection, and sophisticated scroll-stitching for large spreadsheet regions. The system demonstrates advanced MV3 capabilities including service worker lifecycle management, secure content script communication, and efficient resource utilization.

## Project Structure

The extension follows a clean separation of concerns with distinct modules for different responsibilities:

```mermaid
graph TB
subgraph "Extension Root"
Manifest["manifest.json<br/>Extension Configuration"]
subgraph "Background Layer"
Background["background.js<br/>Service Worker"]
end
subgraph "UI Layer"
PopupHTML["popup.html<br/>Popup Interface"]
PopupJS["popup.js<br/>Popup Logic"]
end
subgraph "Content Layer"
ContentJS["content.js<br/>Sheet Interaction"]
end
subgraph "Resources"
Icons["icons/<br/>Extension Icons"]
end
end
Manifest --> Background
Manifest --> PopupHTML
Manifest --> ContentJS
PopupHTML --> PopupJS
PopupJS --> Background
Background --> ContentJS
```

**Diagram sources**
- [manifest.json:1-37](file://manifest.json#L1-L37)
- [background.js:1-72](file://background.js#L1-L72)
- [popup.js:1-87](file://popup.js#L1-L87)
- [content.js:1-1031](file://content.js#L1-L1031)

**Section sources**
- [manifest.json:1-37](file://manifest.json#L1-L37)

## Core Components

The extension architecture consists of four primary components that work together to provide seamless Google Sheets capture functionality:

### Service Worker Background Script
The background script serves as the central coordinator for all extension activities. It handles message routing, screenshot capture operations, and manages the extension's persistent state through Chrome storage APIs.

### Popup Interface
The popup provides the user-facing interface with four distinct capture modes: standard screenshot, area selection, scroll capture, and selection capture. It validates Google Sheets context and coordinates with the content script.

### Content Script
The content script operates within Google Sheets pages to provide interactive capture capabilities including drag selection overlays, scroll simulation, and advanced stitching algorithms for large areas.

### Manifest Configuration
The manifest defines permissions, host permissions, and module loading configurations that enable secure and efficient extension operation.

**Section sources**
- [background.js:1-72](file://background.js#L1-L72)
- [popup.js:1-87](file://popup.js#L1-L87)
- [content.js:1-1031](file://content.js#L1-L1031)
- [manifest.json:1-37](file://manifest.json#L1-L37)

## Architecture Overview

The extension follows a layered architecture pattern optimized for Chrome Extension MV3 constraints:

```mermaid
graph TB
subgraph "User Interface Layer"
Popup["Popup Interface<br/>popup.html + popup.js"]
end
subgraph "Communication Layer"
Runtime["Chrome Runtime API<br/>Message Passing"]
Tabs["Chrome Tabs API<br/>Tab Management"]
Storage["Chrome Storage API<br/>Local Data Storage"]
end
subgraph "Background Processing Layer"
Background["Background Script<br/>background.js"]
CaptureEngine["Capture Engine<br/>Screenshot Logic"]
end
subgraph "Content Interaction Layer"
ContentScript["Content Script<br/>content.js"]
OverlaySystem["Overlay System<br/>Selection UI"]
CaptureAlgorithms["Capture Algorithms<br/>Scroll & Area Logic"]
end
subgraph "External Systems"
GoogleSheets["Google Sheets<br/>Target Application"]
FileSystem["Browser File System<br/>Downloads"]
end
Popup --> Runtime
Popup --> Tabs
Runtime --> Background
Background --> Storage
Background --> CaptureEngine
Popup --> ContentScript
ContentScript --> OverlaySystem
ContentScript --> CaptureAlgorithms
CaptureEngine --> FileSystem
ContentScript --> GoogleSheets
Background --> GoogleSheets
```

**Diagram sources**
- [background.js:1-72](file://background.js#L1-L72)
- [popup.js:1-87](file://popup.js#L1-L87)
- [content.js:1-1031](file://content.js#L1-L1031)

The architecture demonstrates several key MV3 design patterns:

- **Service Worker Lifecycle**: Persistent background processing with automatic lifecycle management
- **Secure Content Script Isolation**: Separated execution context with controlled communication channels
- **Asynchronous Message Passing**: Non-blocking communication between components
- **Resource-Based Access Control**: Controlled exposure of resources to external contexts

## Detailed Component Analysis

### Background Script Architecture

The background script implements a centralized message handler that routes requests to specialized capture functions:

```mermaid
classDiagram
class BackgroundScript {
+onMessageListener listener
+captureScreenshot(tabId) Promise
+captureWithRetry(tries) Promise
+downloadImage(dataUrl, filename) void
+getTimestamp() string
+pad(n) string
}
class CaptureEngine {
+captureVisibleTab(tabId, options) Promise
+retryMechanism(maxAttempts) Promise
+errorHandling(err) object
}
class StorageManager {
+setPreviewData(data) Promise
+getPreviewData() Promise
+clearStorage() Promise
}
class DownloadManager {
+downloadImage(url, filename, options) Promise
+generateFilename(prefix) string
+validateDownloadOptions(options) boolean
}
BackgroundScript --> CaptureEngine : "coordinates"
BackgroundScript --> StorageManager : "manages"
BackgroundScript --> DownloadManager : "handles"
```

**Diagram sources**
- [background.js:1-72](file://background.js#L1-L72)

**Section sources**
- [background.js:1-72](file://background.js#L1-L72)

### Popup Interface Component

The popup interface provides a responsive user interface with contextual awareness:

```mermaid
classDiagram
class PopupInterface {
+btnScreenshot Button
+btnArea Button
+btnTall Button
+btnSelection Button
+statusEl Element
+mainContent Element
+notSheets Element
+setStatus(message, type) void
+validateGoogleSheetsContext() boolean
}
class MessageCoordinator {
+sendToTab(tabId, message) Promise
+injectContentScript(tabId) Promise
+handleInjectionFailure(err) void
}
class UIStateManager {
+showMainContent() void
+showNotSheetsMessage() void
+disableButtons() void
+enableButtons() void
}
PopupInterface --> MessageCoordinator : "uses"
PopupInterface --> UIStateManager : "controls"
```

**Diagram sources**
- [popup.js:1-87](file://popup.js#L1-L87)
- [popup.html:1-181](file://popup.html#L1-L181)

**Section sources**
- [popup.js:1-87](file://popup.js#L1-L87)
- [popup.html:1-181](file://popup.html#L1-L181)

### Content Script Advanced Features

The content script implements sophisticated capture algorithms for different scenarios:

```mermaid
classDiagram
class ContentScript {
+overlay Element
+selectionBox Element
+startAreaSelect() void
+startTallCapture() void
+startSelectionCapture() void
+captureVisible() Promise
+cropImage(dataUrl, rect) Promise
+cleanup() void
}
class OverlaySystem {
+createOverlay() Element
+showSelectionHint() void
+hideOverlay() void
+handleMouseEvents() void
}
class ScrollCaptureEngine {
+findGridContainer() Element
+simulateScrollSteps() Promise
+detectScrollPosition() number
+handleScrollFailure() void
}
class ImageProcessing {
+cropToImageData(img, rect, dpr) ImageData
+stitchVertical(prev, next, expectedDelta) ImageData
+detectFrozenHeader(prev, next) number
+framesAreIdentical(prev, next) boolean
}
ContentScript --> OverlaySystem : "manages"
ContentScript --> ScrollCaptureEngine : "coordinates"
ContentScript --> ImageProcessing : "utilizes"
```

**Diagram sources**
- [content.js:1-1031](file://content.js#L1-L1031)

**Section sources**
- [content.js:1-1031](file://content.js#L1-L1031)

## Security Model and Permissions

The extension implements a comprehensive security model aligned with Chrome Extension MV3 security guidelines:

### Permission Architecture

```mermaid
graph LR
subgraph "Required Permissions"
ActiveTab["activeTab<br/>Access active tab context"]
Scripting["scripting<br/>Programmatic injection"]
Downloads["downloads<br/>File download operations"]
Tabs["tabs<br/>Tab management"]
Storage["storage<br/>Local data persistence"]
end
subgraph "Host Permissions"
SheetsDocs["https://docs.google.com/*<br/>Google Sheets Access"]
AllUrls["<all_urls><br/>Universal Access"]
end
subgraph "Security Boundaries"
Extension["Extension Context<br/>background.js"]
Content["Content Script Context<br/>content.js"]
Target["Target Page Context<br/>Google Sheets"]
end
ActiveTab --> Extension
Scripting --> Extension
Downloads --> Extension
Tabs --> Extension
Storage --> Extension
SheetsDocs --> Extension
AllUrls --> Extension
Extension -.->|"Message Passing"| Content
Content -.->|"DOM Access"| Target
```

**Diagram sources**
- [manifest.json:6-7](file://manifest.json#L6-L7)

### Security Implementation Details

The extension employs several security measures:

- **Isolated Execution Contexts**: Background script and content script operate in separate contexts with controlled communication
- **Permission-Based Access**: All operations require explicit permission declarations in the manifest
- **Host Permission Validation**: Specific Google Sheets URL patterns restrict content script injection
- **Message-Based Communication**: All cross-context communication occurs through structured message passing
- **Resource Access Control**: Only explicitly declared resources are exposed to external contexts

**Section sources**
- [manifest.json:6-7](file://manifest.json#L6-L7)

## Message Passing System

The extension implements a robust message passing system that coordinates between popup, content script, and background script:

```mermaid
sequenceDiagram
participant User as "User"
participant Popup as "Popup Interface"
participant BG as "Background Script"
participant Content as "Content Script"
participant Sheets as "Google Sheets"
Note over User,Sheets : User initiates screenshot capture
User->>Popup : Click "Screenshot" button
Popup->>Popup : Validate Google Sheets context
Popup->>BG : sendMessage({action : 'screenshot', tabId})
BG->>BG : captureScreenshot(tabId)
BG->>BG : captureWithRetry(3)
BG->>BG : captureVisibleTab()
BG->>BG : createPreviewPage()
BG-->>Popup : {success : true}
Popup-->>User : Show success status
Note over User,Sheets : Area selection capture
User->>Popup : Click "Area Select" button
Popup->>Content : sendMessage({action : 'area-select'})
Content->>Content : startAreaSelect()
Content->>Content : createOverlay()
User->>Content : Drag to select area
Content->>BG : sendMessage({action : 'preview', dataUrl})
BG->>BG : storePreviewData()
BG->>BG : openPreviewPage()
BG-->>Content : {success : true}
Content-->>User : Show preview
Note over User,Sheets : Scroll capture
User->>Popup : Click "Scroll Capture" button
Popup->>Content : sendMessage({action : 'tall-capture'})
Content->>Content : startTallCapture()
Content->>Content : simulateScrollSteps()
Content->>Content : captureVisible()
Content->>Content : stitchVertical()
Content->>BG : sendMessage({action : 'preview', dataUrl})
BG->>BG : storePreviewData()
BG->>BG : openPreviewPage()
BG-->>Content : {success : true}
```

**Diagram sources**
- [popup.js:22-43](file://popup.js#L22-L43)
- [background.js:3-27](file://background.js#L3-L27)
- [content.js:11-21](file://content.js#L11-L21)

### Message Types and Handlers

The message passing system supports several distinct message types:

| Message Type | Purpose | Direction | Parameters |
|--------------|---------|-----------|------------|
| `screenshot` | Full page screenshot capture | Popup → Background | `tabId` |
| `capture-visible` | Visible tab capture | Content → Background | None |
| `preview` | Preview image data | Content/Background → Background | `dataUrl`, `filename` |
| `download` | Direct download initiation | Background → Background | `dataUrl`, `filename` |
| `area-select` | Interactive area selection | Popup → Content | None |
| `tall-capture` | Scroll capture mode | Popup → Content | None |
| `capture-selection` | Selected cell capture | Popup → Content | None |

**Section sources**
- [popup.js:22-86](file://popup.js#L22-L86)
- [background.js:2-27](file://background.js#L2-L27)
- [content.js:11-21](file://content.js#L11-L21)

## Data Flow Analysis

The extension processes user actions through a well-defined data flow pipeline:

```mermaid
flowchart TD
Start([User Action]) --> ValidateContext["Validate Google Sheets Context"]
ValidateContext --> ContextValid{"Valid Google Sheets?"}
ContextValid --> |No| ShowMessage["Show 'Open Google Sheet' message"]
ContextValid --> |Yes| ProcessAction["Process User Action"]
ProcessAction --> ActionChoice{"Action Type"}
ActionChoice --> |Screenshot| CaptureVisible["Capture Visible Tab"]
ActionChoice --> |Area Select| ShowOverlay["Show Selection Overlay"]
ActionChoice --> |Scroll Capture| StartScrollCapture["Start Scroll Capture"]
ActionChoice --> |Selection Capture| CaptureSelection["Capture Selection"]
CaptureVisible --> GeneratePreview["Generate Preview Data"]
ShowOverlay --> UserInteraction["User Drags Selection"]
StartScrollCapture --> SimulateScroll["Simulate Scroll Steps"]
CaptureSelection --> GetSelectionInfo["Get Selection Information"]
UserInteraction --> CaptureArea["Capture Selected Area"]
SimulateScroll --> CaptureFrame["Capture Frame"]
GetSelectionInfo --> CaptureSelectionFrame["Capture Selection Frame"]
CaptureArea --> CropImage["Crop to Selection"]
CaptureFrame --> ProcessFrame["Process Frame"]
CaptureSelectionFrame --> CropSelection["Crop Selection"]
ProcessFrame --> StitchImages["Stitch Images Together"]
CropImage --> StoreData["Store Preview Data"]
CropSelection --> StoreData
StitchImages --> StoreData
StoreData --> OpenPreview["Open Preview Page"]
OpenPreview --> End([Operation Complete])
ShowMessage --> End
```

**Diagram sources**
- [content.js:98-131](file://content.js#L98-L131)
- [content.js:281-440](file://content.js#L281-L440)
- [content.js:645-800](file://content.js#L645-L800)

### Data Transformation Pipeline

The extension implements a sophisticated data transformation pipeline:

1. **Initial Capture**: Browser tab capture produces raw image data
2. **Image Processing**: Canvas-based cropping and scaling operations
3. **Advanced Processing**: Scroll-stitching algorithms for large areas
4. **Data Storage**: Local storage of preview data for rendering
5. **Output Generation**: Preview page creation and download initiation

**Section sources**
- [content.js:166-190](file://content.js#L166-L190)
- [content.js:480-529](file://content.js#L480-L529)
- [background.js:42-54](file://background.js#L42-L54)

## MV3 Migration Benefits

The extension leverages several key benefits of Chrome Extension MV3:

### Service Worker Advantages

- **Improved Performance**: Service workers provide better memory management and reduced startup times
- **Enhanced Security**: Isolated execution contexts with stricter security boundaries
- **Better Resource Management**: Automatic lifecycle management reduces resource leaks
- **Modern Web Standards**: Alignment with current web platform capabilities

### Enhanced Security Model

- **Manifest V3 Compliance**: Built-in support for modern security patterns
- **Reduced Attack Surface**: Limited permissions and controlled access patterns
- **Improved Privacy Controls**: Better isolation between extension and target pages
- **Automatic Updates**: Streamlined update mechanisms with rollback capabilities

### Developer Experience Improvements

- **Simplified APIs**: Consistent messaging and storage APIs across contexts
- **Better Debugging**: Enhanced developer tools and logging capabilities
- **Performance Monitoring**: Built-in metrics and performance tracking
- **Cross-Browser Compatibility**: Standardized patterns for broader compatibility

## Architectural Constraints

The extension operates under several MV3 architectural constraints:

### Service Worker Limitations

- **No DOM Access**: Background scripts cannot directly manipulate page DOM
- **Limited Network Access**: Requires explicit host permissions for external URLs
- **Storage Constraints**: Local storage limitations and quota management
- **Lifecycle Management**: Service worker termination and restart policies

### Content Script Restrictions

- **Execution Context**: Content scripts run in target page context with limited access
- **Communication Boundaries**: Must use structured messaging for cross-context communication
- **Resource Loading**: Cannot directly load extension resources without proper declaration
- **Timing Constraints**: Must account for page load timing and availability

### Security Implications

- **Permission Model**: All capabilities require explicit permission declarations
- **Host Permission Scope**: Must declare all URLs where content scripts will execute
- **Resource Exposure**: Only explicitly declared resources can be accessed externally
- **Cross-Origin Restrictions**: Strict same-origin policies apply to content scripts

**Section sources**
- [manifest.json:21-36](file://manifest.json#L21-L36)

## Performance Considerations

The extension implements several performance optimization strategies:

### Memory Management

- **Canvas Resource Cleanup**: Proper disposal of canvas elements and image data
- **Event Listener Management**: Dynamic addition and removal of event listeners
- **Memory Leak Prevention**: Careful management of DOM references and closures
- **Image Data Optimization**: Efficient handling of large image data arrays

### Network Efficiency

- **Retry Mechanisms**: Intelligent retry logic with exponential backoff
- **Rate Limiting**: Respect browser capture API rate limits and constraints
- **Batch Operations**: Minimized network requests through batch processing
- **Caching Strategies**: Strategic use of local storage for intermediate results

### User Experience Optimization

- **Progress Indicators**: Real-time feedback during long-running operations
- **Responsive UI**: Non-blocking operations with immediate user feedback
- **Error Recovery**: Graceful degradation and user-friendly error messages
- **Performance Monitoring**: Built-in metrics for identifying bottlenecks

## Troubleshooting Guide

Common issues and their solutions:

### Content Script Injection Failures

**Symptoms**: Buttons disabled, error messages about content script not found
**Causes**: Content script not injected, Google Sheets context not detected
**Solutions**: Verify manifest content script matches, check host permissions, ensure proper injection logic

### Capture Operation Failures

**Symptoms**: Empty capture results, error messages during capture
**Causes**: Rate limiting, timing issues, DOM not ready
**Solutions**: Implement retry mechanisms, add delays for page readiness, handle rate limit errors gracefully

### Storage and Preview Issues

**Symptoms**: Preview page not opening, missing image data
**Causes**: Storage quota exceeded, invalid data URLs, permission issues
**Solutions**: Monitor storage usage, validate data URLs, check storage permissions

### Cross-Context Communication Problems

**Symptoms**: Messages not received, timeout errors
**Causes**: Incorrect message format, timing issues, context mismatches
**Solutions**: Validate message structure, implement proper error handling, ensure proper context initialization

**Section sources**
- [popup.js:45-56](file://popup.js#L45-L56)
- [background.js:29-40](file://background.js#L29-L40)
- [content.js:150-164](file://content.js#L150-L164)

## Conclusion

This Chrome Extension MV3 architecture demonstrates a sophisticated approach to browser automation and image processing. The design successfully balances functionality with security constraints, providing users with powerful Google Sheets capture capabilities while maintaining strict adherence to MV3 security guidelines.

The modular architecture enables clear separation of concerns, with each component having well-defined responsibilities and communication boundaries. The message passing system ensures reliable coordination between popup, content script, and background components, while the security model protects both user privacy and system integrity.

Key architectural strengths include the robust retry mechanisms for capture operations, sophisticated scroll-stitching algorithms for large area captures, and comprehensive error handling throughout the system. The MV3 migration provides improved performance, security, and maintainability compared to legacy extension architectures.

Future enhancements could include additional capture modes, improved performance optimization, and expanded customization options while maintaining the current security and architectural foundations.