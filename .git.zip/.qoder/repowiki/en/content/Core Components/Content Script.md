# Content Script

<cite>
**Referenced Files in This Document**
- [content.js](file://content.js)
- [content.css](file://content.css)
- [manifest.json](file://manifest.json)
- [background.js](file://background.js)
- [popup.js](file://popup.js)
- [popup.html](file://popup.html)
- [preview.html](file://preview.html)
- [preview.js](file://preview.js)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document describes the content script component that integrates with Google Sheets to capture screenshots. It covers:
- Area selection overlay system with interactive crosshair cursor, real-time selection box rendering, and mouse event handling
- Scroll capture engine with intelligent frame capture, overlap detection, and frozen header handling
- A1 notation parsing for cell ranges, grid container detection, and column-based cropping
- Canvas processing for high-DPI support via device pixel ratio compensation
- CSS overlay styles and DOM manipulation techniques used for Google Sheets integration

## Project Structure
The extension consists of:
- Manifest declaring content script injection for Google Sheets
- Content script implementing capture modes and overlays
- CSS overlay styles for selection UI
- Background script handling tab capture and downloads
- Popup UI to trigger capture modes
- Preview UI to display and manage captured images

```mermaid
graph TB
subgraph "Extension"
M["manifest.json"]
CS["content.js"]
CC["content.css"]
BG["background.js"]
POP["popup.js"]
PREV["preview.js"]
end
subgraph "Google Sheets"
GS["Spreadsheet Page"]
end
M --> CS
M --> CC
POP --> CS
CS --> BG
CS --> GS
BG --> PREV
```

**Diagram sources**
- [manifest.json:19-23](file://manifest.json#L19-L23)
- [content.js:1-9](file://content.js#L1-L9)
- [content.css:1-35](file://content.css#L1-L35)
- [background.js:1-47](file://background.js#L1-L47)
- [popup.js:16-34](file://popup.js#L16-L34)
- [preview.js:1-180](file://preview.js#L1-L180)

**Section sources**
- [manifest.json:19-23](file://manifest.json#L19-L23)
- [content.js:1-9](file://content.js#L1-L9)
- [content.css:1-35](file://content.css#L1-L35)
- [background.js:1-47](file://background.js#L1-L47)
- [popup.js:16-34](file://popup.js#L16-L34)
- [preview.js:1-180](file://preview.js#L1-L180)

## Core Components
- Content script entrypoint: listens for messages from the popup and executes capture modes
- Overlay system: creates a full-screen overlay with a crosshair cursor and a real-time selection rectangle
- Scroll capture engine: captures multiple frames while scrolling, detects overlaps, and handles frozen headers
- A1 notation parser: converts A1 cell references to numeric coordinates
- Grid container detection: locates the spreadsheet grid and canvas geometry
- Column-based cropping: crops captured images to selected columns
- Canvas processing: compensates for high-DPI displays using device pixel ratio
- CSS overlay styles: fixed-position overlay, selection box, and dimension label
- DOM integration: manipulates the page to show overlays and read selection metadata

**Section sources**
- [content.js:4-9](file://content.js#L4-L9)
- [content.js:47-136](file://content.js#L47-L136)
- [content.js:140-668](file://content.js#L140-L668)
- [content.js:690-763](file://content.js#L690-L763)
- [content.js:760-763](file://content.js#L760-L763)
- [content.css:1-35](file://content.css#L1-L35)

## Architecture Overview
The content script acts as a bridge between the extension’s UI and the Google Sheets page. It injects overlays, captures frames, processes images, and communicates with the background script to preview and download results.

```mermaid
sequenceDiagram
participant User as "User"
participant Popup as "Popup UI"
participant CS as "Content Script"
participant BG as "Background Script"
participant Sheet as "Google Sheets"
User->>Popup : Click capture mode
Popup->>CS : sendMessage(action)
CS->>Sheet : Inject overlay / scroll / selection logic
CS->>BG : Request tab capture
BG-->>CS : dataUrl
CS->>CS : Crop/Process image
CS->>BG : Preview image
BG-->>Popup : Open preview
```

**Diagram sources**
- [popup.js:10-44](file://popup.js#L10-L44)
- [content.js:25-43](file://content.js#L25-L43)
- [background.js:1-47](file://background.js#L1-L47)
- [preview.js:24-37](file://preview.js#L24-L37)

## Detailed Component Analysis

### Area Selection Overlay System
The area capture mode:
- Creates a full-screen overlay with a crosshair cursor
- Tracks mouse events to render a real-time dashed selection box
- Computes selection rectangle and triggers a tab capture
- Crops the captured image to the selection region using device pixel ratio compensation
- Provides ESC to cancel

```mermaid
flowchart TD
Start(["Start Area Capture"]) --> CreateOverlay["Create overlay and attach to body"]
CreateOverlay --> MouseDown["Mouse down: record start position"]
MouseDown --> MouseMove["Mouse move: update selection box"]
MouseMove --> MouseUp["Mouse up: compute rect"]
MouseUp --> Validate["Validate selection size"]
Validate --> |Too small| Cancel["Cancel selection"]
Validate --> |OK| Capture["Request tab capture"]
Capture --> Crop["Crop to selection<br/>with DPR compensation"]
Crop --> Preview["Send to preview"]
Cancel --> End(["End"])
Preview --> End
```

**Diagram sources**
- [content.js:47-136](file://content.js#L47-L136)

**Section sources**
- [content.js:47-136](file://content.js#L47-L136)
- [content.css:1-11](file://content.css#L1-L11)

### Scroll Capture Engine
The tall capture mode:
- Detects the grid container and scrollable element
- Measures grid canvas geometry
- Scrolls incrementally and captures frames
- Uses an overlap detection algorithm to avoid redundant frames
- Handles frozen rows/columns by detecting frozen header boundaries
- Compensates for high-DPI by sampling at device pixel ratio

```mermaid
flowchart TD
Init(["Init Tall Capture"]) --> Detect["Detect grid container and scroll element"]
Detect --> Measure["Measure grid canvas rect"]
Measure --> ScrollLoop["Scroll loop"]
ScrollLoop --> CaptureFrame["Capture frame"]
CaptureFrame --> OverlapCheck{"Overlap detected?"}
OverlapCheck --> |Yes| Skip["Skip frame"]
OverlapCheck --> |No| AddFrame["Add frame"]
AddFrame --> FrozenCheck{"Frozen header?"}
FrozenCheck --> |Yes| Adjust["Adjust for frozen rows"]
FrozenCheck --> |No| Continue["Continue"]
Adjust --> Continue
Continue --> ScrollLoop
Skip --> ScrollLoop
ScrollLoop --> Done(["Assemble frames"])
```

**Diagram sources**
- [content.js:140-668](file://content.js#L140-L668)
- [content.js:664-668](file://content.js#L664-L668)
- [content.js:670-688](file://content.js#L670-L688)

**Section sources**
- [content.js:140-668](file://content.js#L140-L668)
- [content.js:670-688](file://content.js#L670-L688)
- [content.js:664-668](file://content.js#L664-L668)

### A1 Notation Parsing and Grid Container Detection
- Parses A1 notation ranges into numeric coordinates for columns and rows
- Converts alphabetic column labels to numbers
- Locates the selection bounding rectangle using known selection classes
- Identifies the grid container and canvas geometry for cropping and scrolling

```mermaid
flowchart TD
Parse["Parse A1 text"] --> RangeOrCell{"Range or single cell?"}
RangeOrCell --> |Range| ParseRange["Extract start/end cols/rows"]
RangeOrCell --> |Cell| ParseCell["Set start=end for row/col"]
ParseRange --> ConvertCols["Convert A-Z to numbers"]
ParseCell --> ConvertCols
ConvertCols --> Result["Numeric coordinates"]
```

**Diagram sources**
- [content.js:729-758](file://content.js#L729-L758)
- [content.js:760-763](file://content.js#L760-L763)

**Section sources**
- [content.js:729-758](file://content.js#L729-L758)
- [content.js:760-763](file://content.js#L760-L763)

### Column-Based Cropping and Canvas Processing
- Uses device pixel ratio to scale canvases and maintain crispness on high-DPI displays
- Converts image data to a canvas, crops to the selection rectangle, and exports as PNG
- Applies the same scaling factor when computing selection rectangles

```mermaid
sequenceDiagram
participant CS as "Content Script"
participant BG as "Background Script"
participant Canvas as "Canvas API"
CS->>BG : Request tab capture
BG-->>CS : dataUrl
CS->>Canvas : Create offscreen canvas
CS->>Canvas : putImageData(imageData)
CS->>Canvas : crop(rect, dpr)
Canvas-->>CS : cropped ImageData
CS->>Canvas : toDataURL("image/png")
CS-->>BG : preview
```

**Diagram sources**
- [content.js:101-115](file://content.js#L101-L115)
- [background.js:1-47](file://background.js#L1-L47)

**Section sources**
- [content.js:101-115](file://content.js#L101-L115)

### CSS Overlay Styles and DOM Manipulation
- Overlay styles define a full-screen fixed layer with crosshair cursor and high z-index
- Selection box uses dashed borders, semi-transparent fill, and shadow for visibility
- Dimension label shows the selection size below the box
- DOM insertion appends the overlay to the document body during area capture

```mermaid
classDiagram
class OverlayStyles {
+fixed position
+crosshair cursor
+z-index high
+pointer-events none
}
class SelectionBox {
+absolute position
+dashed border
+semi-transparent fill
+shadow
}
class DimensionLabel {
+absolute position
+monospace font
+black background
}
OverlayStyles <.. SelectionBox : "used by"
OverlayStyles <.. DimensionLabel : "used by"
```

**Diagram sources**
- [content.css:1-35](file://content.css#L1-L35)

**Section sources**
- [content.css:1-35](file://content.css#L1-L35)
- [content.js:49-51](file://content.js#L49-L51)

## Dependency Analysis
- Content script depends on:
  - Background script for tab capture and download
  - Popup script for user-triggered actions
  - Google Sheets DOM for overlays and selection detection
- External dependencies:
  - Chrome extension APIs for messaging and scripting
  - Canvas API for image processing
  - Device pixel ratio for high-DPI compensation

```mermaid
graph LR
Popup["popup.js"] --> CS["content.js"]
CS --> BG["background.js"]
CS --> Sheet["Google Sheets DOM"]
BG --> Preview["preview.html/js"]
```

**Diagram sources**
- [popup.js:10-44](file://popup.js#L10-L44)
- [content.js:25-43](file://content.js#L25-L43)
- [background.js:1-47](file://background.js#L1-L47)
- [preview.js:1-180](file://preview.js#L1-L180)

**Section sources**
- [popup.js:10-44](file://popup.js#L10-L44)
- [content.js:25-43](file://content.js#L25-L43)
- [background.js:1-47](file://background.js#L1-L47)
- [preview.js:1-180](file://preview.js#L1-L180)

## Performance Considerations
- Frame overlap detection reduces redundant captures and speeds up scroll capture
- Sampling pixels at intervals minimizes computation while maintaining accuracy
- Device pixel ratio compensation ensures crisp output on high-resolution displays
- Offscreen canvas operations keep UI responsive during image processing

## Troubleshooting Guide
- Overlay not appearing:
  - Verify the overlay class is appended to the body and z-index is sufficiently high
  - Confirm the content script is injected on Google Sheets URLs
- Selection box not updating:
  - Ensure mousemove handlers are attached and selection element is positioned absolutely
  - Check that ESC handler removes the overlay cleanly
- Scroll capture not working:
  - Confirm the grid container and scroll element are correctly identified
  - Validate that overlap detection does not skip all frames
- High-DPI blurriness:
  - Ensure device pixel ratio is applied consistently when drawing and cropping
- Preview not opening:
  - Check background script message handling and storage-based data passing

**Section sources**
- [content.js:49-51](file://content.js#L49-L51)
- [content.js:127-135](file://content.js#L127-L135)
- [content.js:140-668](file://content.js#L140-L668)
- [content.js:101-115](file://content.js#L101-L115)
- [background.js:26-33](file://background.js#L26-L33)

## Conclusion
The content script provides a robust solution for capturing Google Sheets with four distinct modes: simple screenshot, area selection, scroll capture, and selection-based capture. Its overlay system, intelligent frame capture, A1 parsing, and high-DPI canvas processing deliver a polished user experience integrated seamlessly into the Sheets interface.