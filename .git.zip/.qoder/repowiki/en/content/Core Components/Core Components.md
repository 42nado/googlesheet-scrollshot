# Core Components

<cite>
**Referenced Files in This Document**
- [manifest.json](file://manifest.json)
- [popup.html](file://popup.html)
- [popup.js](file://popup.js)
- [background.js](file://background.js)
- [content.js](file://content.js)
- [content.css](file://content.css)
- [preview.html](file://preview.html)
- [preview.js](file://preview.js)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the core extension components that enable capturing screenshots and scrollshots of Google Sheets. It covers:
- Popup interface: Google Sheets detection, action buttons, and status indicators
- Background script: screenshot capture, retry logic, and preview coordination
- Content script: Google Sheets-specific features including area selection overlay, scroll capture engine, and A1 notation parsing
- Preview interface: zoom controls, clipboard integration, and download functionality
- Content styles for overlays and user interface elements

## Project Structure
The extension follows a Manifest V3 architecture with a service worker background script, a content script injected into Google Sheets, a popup UI, and a preview page.

```mermaid
graph TB
subgraph "Extension"
M["manifest.json"]
BG["background.js"]
POP["popup.html + popup.js"]
CS["content.js + content.css"]
PREV["preview.html + preview.js"]
end
M --> BG
M --> POP
M --> CS
M --> PREV
POP --> BG
POP --> CS
CS --> BG
BG --> PREV
```

**Diagram sources**
- [manifest.json:1-37](file://manifest.json#L1-L37)
- [popup.html:1-181](file://popup.html#L1-L181)
- [popup.js:1-87](file://popup.js#L1-L87)
- [background.js:1-72](file://background.js#L1-L72)
- [content.js:1-1031](file://content.js#L1-L1031)
- [content.css:1-2](file://content.css#L1-L2)
- [preview.html:1-171](file://preview.html#L1-L171)
- [preview.js:1-242](file://preview.js#L1-L242)

**Section sources**
- [manifest.json:1-37](file://manifest.json#L1-L37)

## Core Components
- Popup UI: Detects whether the active tab is a Google Sheets URL and exposes actions for screenshot, area selection, scroll capture, and capture selection. It also displays status messages and disables buttons during operations.
- Background script: Performs tab capture, retries on failure, opens the preview page, and triggers downloads.
- Content script: Implements area selection overlay, scroll capture engine, A1 notation parsing, and selection capture.
- Preview page: Provides zoom controls, copy-to-clipboard, and download actions with keyboard and mouse interactions.

**Section sources**
- [popup.html:1-181](file://popup.html#L1-L181)
- [popup.js:1-87](file://popup.js#L1-L87)
- [background.js:1-72](file://background.js#L1-L72)
- [content.js:1-1031](file://content.js#L1-L1031)
- [preview.html:1-171](file://preview.html#L1-L171)
- [preview.js:1-242](file://preview.js#L1-L242)

## Architecture Overview
The extension coordinates between the popup, background script, content script, and preview page.

```mermaid
sequenceDiagram
participant U as "User"
participant P as "Popup (popup.js)"
participant BG as "Background (background.js)"
participant CS as "Content Script (content.js)"
participant PR as "Preview (preview.js)"
U->>P : Click action button
P->>CS : sendMessage(action)
CS->>BG : sendMessage(capture-visible)
BG-->>CS : {dataUrl}
CS->>BG : sendMessage(preview)
BG->>PR : Open preview.html with image data
PR-->>U : Display image with controls
U->>PR : Copy to Clipboard / Download
PR->>BG : sendMessage(download)
BG-->>U : Download initiated
```

**Diagram sources**
- [popup.js:22-86](file://popup.js#L22-L86)
- [background.js:2-27](file://background.js#L2-L27)
- [content.js:150-164](file://content.js#L150-L164)
- [preview.js:53-94](file://preview.js#L53-L94)

## Detailed Component Analysis

### Popup Interface
- Google Sheets detection: Queries the active tab and hides main actions if the URL does not match Google Sheets.
- Action buttons:
  - Screenshot: Captures the visible tab and routes to preview.
  - Area Screenshot: Injects overlay to select a region.
  - Scroll Capture: Initiates top-to-bottom stitching.
  - Capture Selection: Uses A1 notation to capture a named range.
- Status indicators: Displays success/error messages with color-coded classes.

```mermaid
flowchart TD
Start(["Open Popup"]) --> Check["Check active tab URL"]
Check --> |Is Google Sheets| ShowMain["Show main actions"]
Check --> |Not Google Sheets| ShowNotice["Show 'Open a Google Sheet' notice"]
ShowMain --> ClickAction{"User clicks action"}
ClickAction --> |Screenshot| SendCapture["Send capture message"]
ClickAction --> |Area| SendArea["Inject overlay via content script"]
ClickAction --> |Scroll| SendTall["Start scroll capture"]
ClickAction --> |Selection| SendSel["Capture selection"]
SendCapture --> Close["Close popup"]
SendArea --> Close
SendTall --> Close
SendSel --> Close
```

**Diagram sources**
- [popup.html:138-176](file://popup.html#L138-L176)
- [popup.js:14-20](file://popup.js#L14-L20)
- [popup.js:22-86](file://popup.js#L22-L86)

**Section sources**
- [popup.html:1-181](file://popup.html#L1-L181)
- [popup.js:1-87](file://popup.js#L1-L87)

### Background Script
- Message handling:
  - Screenshot: Captures the visible tab and opens preview.
  - Capture-visible: Retries capture with exponential backoff.
  - Preview: Stores image data and opens preview page.
  - Download: Triggers browser download.
- Retry logic: Attempts capture multiple times with short delays, returning the first successful result or the last error.
- Timestamping: Generates filenames with timestamps.

```mermaid
flowchart TD
Msg["Runtime message received"] --> Type{"Action type"}
Type --> |screenshot| Cap["Capture visible tab"]
Type --> |capture-visible| Retry["Retry capture loop"]
Type --> |preview| Store["Store previewData and open preview.html"]
Type --> |download| DL["Trigger download"]
Cap --> OpenPrev["Open preview.html"]
Retry --> Done["Resolve with dataUrl or error"]
Store --> Done
DL --> Done
```

**Diagram sources**
- [background.js:2-27](file://background.js#L2-L27)
- [background.js:29-40](file://background.js#L29-L40)
- [background.js:42-54](file://background.js#L42-L54)
- [background.js:56-62](file://background.js#L56-L62)

**Section sources**
- [background.js:1-72](file://background.js#L1-L72)

### Content Script (Google Sheets Features)
- Overlay and area selection:
  - Creates an overlay with a draggable selection box and hints.
  - On release, captures the visible tab, crops to the selection rectangle, and previews.
- Scroll capture engine:
  - Detects the grid container and canvas area.
  - Scrolls incrementally using wheel events and direct scrollTop adjustments.
  - Stitches frames vertically, detecting frozen headers and overlaps.
  - Cancels on Escape and stops after repeated duplicates or no scroll progress.
- A1 notation parsing and selection capture:
  - Reads the Name Box to extract a range string.
  - Parses A1 notation into start/end row/column indices.
  - For small selections, captures and crops the visible area.
  - For large selections, uses scroll-and-stitch to capture the full range.

```mermaid
sequenceDiagram
participant P as "Popup"
participant CS as "Content Script"
participant BG as "Background"
P->>CS : sendMessage(area-select)
CS->>CS : Create overlay and selection box
CS->>CS : Mouse events (down/move/up)
CS->>BG : sendMessage(capture-visible)
BG-->>CS : {dataUrl}
CS->>CS : cropImage(dataUrl, rect)
CS->>BG : sendMessage(preview)
BG-->>CS : ack
CS->>CS : cleanup()
```

**Diagram sources**
- [content.js:23-148](file://content.js#L23-L148)
- [content.js:150-164](file://content.js#L150-L164)
- [content.js:166-181](file://content.js#L166-L181)
- [background.js:13-20](file://background.js#L13-L20)

```mermaid
flowchart TD
StartSel(["Start Selection Capture"]) --> ReadName["Read Name Box value/text"]
ReadName --> Parse["Parse A1 notation"]
Parse --> SmallSel{"Rows <= 3?"}
SmallSel --> |Yes| Visible["Capture visible tab"]
Visible --> CropSel["Crop to selection bounding rect"]
CropSel --> PreviewSel["Send to preview"]
SmallSel --> |No| InitScroll["Init scroll capture loop"]
InitScroll --> Loop["Loop: capture -> detect grid -> scroll -> stitch"]
Loop --> Stop{"Stop condition<br/>cancel/duplicates/no scroll"}
Stop --> |Stop| PreviewSel
```

**Diagram sources**
- [content.js:645-800](file://content.js#L645-L800)
- [content.js:281-440](file://content.js#L281-L440)

**Section sources**
- [content.js:1-1031](file://content.js#L1-L1031)

### Preview Interface
- Controls:
  - Zoom: In/Out/Reset with Fit mode and percentage display.
  - Copy to Clipboard: Attempts Clipboard API, falls back to canvas conversion.
  - Download: Sends download message to background.
- Interactions:
  - Keyboard shortcuts: Ctrl++/Ctrl+-
  - Mouse wheel with Ctrl for zoom
  - Drag-to-pan when zoomed
- Status feedback: Temporary status messages.

```mermaid
sequenceDiagram
participant PR as "Preview"
participant BG as "Background"
PR->>PR : Load previewData from storage
PR->>PR : Display image and enable controls
PR->>PR : User clicks Copy
PR->>PR : Try Clipboard API
PR->>PR : Fallback to canvas blob
PR->>PR : Show status "Copied!"
PR->>BG : sendMessage(download)
BG-->>PR : ack
PR->>PR : Show status "Downloading..."
```

**Diagram sources**
- [preview.html:148-168](file://preview.html#L148-L168)
- [preview.js:23-51](file://preview.js#L23-L51)
- [preview.js:53-94](file://preview.js#L53-L94)

**Section sources**
- [preview.html:1-171](file://preview.html#L1-L171)
- [preview.js:1-242](file://preview.js#L1-L242)

### Content Styles
- Overlay and hint styles are created dynamically by the content script for area selection and scroll capture hints.
- The content CSS file is minimal and intended for scrollshot mode.

**Section sources**
- [content.js:26-71](file://content.js#L26-L71)
- [content.js:198-228](file://content.js#L198-L228)
- [content.css:1-2](file://content.css#L1-L2)

## Dependency Analysis
- Permissions and matches:
  - Active tab and scripting permissions for tab manipulation and content injection.
  - Downloads permission for saving images.
  - Host permissions for Google Sheets and all URLs.
  - Content script restricted to Google Sheets domains.
  - Web-accessible resource allows preview.html to be opened by the background script.
- Messaging:
  - Popup communicates with content script and background script.
  - Content script communicates with background script for capture and preview.
  - Background script coordinates preview and download actions.

```mermaid
graph LR
POP["popup.js"] -- "sendMessage(action)" --> CS["content.js"]
CS -- "sendMessage(capture-visible)" --> BG["background.js"]
CS -- "sendMessage(preview)" --> BG
BG -- "open preview.html" --> PREV["preview.html"]
PREV -- "sendMessage(download)" --> BG
```

**Diagram sources**
- [manifest.json:6-36](file://manifest.json#L6-L36)
- [popup.js:22-86](file://popup.js#L22-L86)
- [content.js:150-164](file://content.js#L150-L164)
- [background.js:13-27](file://background.js#L13-L27)
- [preview.js:86-94](file://preview.js#L86-L94)

**Section sources**
- [manifest.json:1-37](file://manifest.json#L1-L37)

## Performance Considerations
- Retry strategy: The background capture-with-retry loop reduces transient failures by retrying with a short delay.
- Device pixel ratio: Cropping and drawing operations account for device pixel ratio to preserve quality.
- Scroll capture efficiency: Uses wheel events and direct scrollTop adjustments, with duplicate frame detection and early termination to avoid unnecessary work.
- Rendering cadence: Delays between frames accommodate rendering and capture rate limits.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
- Popup shows “Open a Google Sheet” notice:
  - Ensure the active tab is a Google Sheets URL.
- Screenshot fails:
  - Verify permissions and try again; the background script retries capture automatically.
- Area selection not working:
  - Confirm overlay appears and selection box is visible; try dragging again and press Escape to cancel.
- Scroll capture stops unexpectedly:
  - Check for duplicate frames or no scroll progress; adjust selection or try again.
- Preview not opening:
  - Confirm the background script stored preview data and opened preview.html.
- Copy to clipboard fails:
  - The preview page attempts a fallback using a canvas; try again or use Download.

**Section sources**
- [popup.js:14-20](file://popup.js#L14-L20)
- [background.js:29-40](file://background.js#L29-L40)
- [content.js:98-131](file://content.js#L98-L131)
- [content.js:311-414](file://content.js#L311-L414)
- [preview.js:53-83](file://preview.js#L53-L83)

## Conclusion
The extension integrates a popup UI, background capture with retry logic, a content script tailored for Google Sheets, and a preview page with robust controls. Together, they provide flexible capture modes—visible, area, scroll, and selection—while ensuring reliability and usability.